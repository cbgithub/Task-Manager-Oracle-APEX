
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "STATUSES_V" ("STATUS_ID", "STATUS_NAME", "STATUS_DESCRIPTION") AS 
  select status_id, status_name, status_description from statuses with read only;