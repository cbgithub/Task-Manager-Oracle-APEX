
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "TASKS_V" ("TASK_ID", "TITLE", "DESCRIPTION", "STATUS_ID", "CREATED_AT", "DUE_DATE", "ASSIGNED_TO_USER") AS 
  SELECT 
    t.task_id, 
    t.title, 
    t.description, 
    t.status_id, 
    t.created_at, 
    t.due_date, 
    t.assigned_user_name AS assigned_to_user
FROM 
    tasks t
WHERE 
    (

                -- Regular users see only their assigned tasks
      t.assigned_user_name = (
        SELECT user_name 
        FROM apex_appl_acl_users 
        WHERE user_name = SYS_CONTEXT('APEX$SESSION', 'APP_USER') and APPLICATION_ID = V('APP_ID')
        )

    )
    OR 
    (
        
         EXISTS (
            SELECT 1
            FROM apex_appl_acl_user_roles ur 
            WHERE ur.user_name = SYS_CONTEXT('APEX$SESSION', 'APP_USER') 
            
            AND ur.role_name IN ('Manager', 'Admin')  and APPLICATION_ID = V('APP_ID')
        )
    )
  with read only;