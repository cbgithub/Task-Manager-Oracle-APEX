create or replace package "TMS_PKG" as
          
    procedure create_task(p_title varchar2, p_description clob, p_assigned_user_name varchar2, p_status_id number, p_due_date date);

    procedure edit_task(p_task_id number, p_title varchar2, p_description clob, p_assigned_user_name varchar2, p_status_id number, p_due_date date);

    procedure delete_task(p_task_id number);

    procedure create_user(p_username varchar2, p_email varchar2, p_role_id varchar2);

    procedure edit_user(p_user_id number,p_username varchar2, p_email varchar2, p_role_id varchar2);

    procedure delete_user(p_user_name varchar2);

    procedure create_role(p_role_name varchar2, p_role_description clob);

    procedure edit_role(p_role_id number, p_role_name varchar2, p_role_description clob);

    procedure delete_role(p_role_id number);

    procedure create_status(p_status_name varchar2, p_status_description clob);

    procedure edit_status(p_status_id number, p_status_name varchar2, p_status_description clob);

    procedure delete_status(p_status_id number);
    

end "TMS_PKG";
/