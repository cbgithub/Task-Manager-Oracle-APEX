
  CREATE OR REPLACE FORCE EDITIONABLE VIEW "USER_V" ("ACL_USER_ID", "ACL_USERNAME", "ACL_USER_ROLE_IDS", "ACL_USER_ROLE_NAMES", "WORKSPACE_EMAIL") AS 
  SELECT 
    acl_user.id AS acl_user_id,
    acl_user.user_name AS acl_username,
    acl_user.role_ids as acl_user_role_ids,
    acl_user.role_names as acl_user_role_names,
    ws_user.email AS workspace_email
FROM 
    apex_appl_acl_users acl_user
JOIN 
    apex_workspace_apex_users ws_user 
ON 
    acl_user.user_name = ws_user.user_name

    where acl_user.application_id = V('APP_ID') and ws_user.is_admin = 'No';