var apex;
((apex ||= {}).redwood ||= {}).actionMenu = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/js/redwood.action-menu.js
  var redwood_action_menu_exports = {};
  __export(redwood_action_menu_exports, {
    init: () => init
  });
  var init = function(daContext, config) {
    apex.debug.info("Oracle Redwood - Action Menu", config, daContext);
    const CLS_JS_MENU_BUTTON = "js-menuButton";
    const CLS_IS_ACTIVE = "is-active";
    const CLS_PLUGIN = "apex-action-button";
    const DATA_ATTR_BTN_MENU = "data-menu";
    const DATA_ATTR_INLINE_BTN = "data-inline-buttons";
    const DATA_ATTR_ACTION_NAME = "data-action-name";
    const DATA_MENU_ID = "data-menu-id";
    const DATA_MENU_FILTER = "data-menu-filter";
    const DATA_MENU_ID_CHECKSUM = "data-menu-id-checksum";
    const DATASET_MENU_ID = "menuId";
    const DATASET_MENU_FILTER = "menuFilter";
    const MENU_ITEM_TYPE_ACTION = "action";
    const MENU_ITEM_TYPE_SEPARATOR = "separator";
    const MENU_ITEM_TYPE_MENU = "subMenu";
    const ICON_UT_MENU = "fa-ellipsis-h";
    const ICON_RW_MENU = "oj-ux-ico-overflow-h";
    const SHOW_ALL_ENTRIES = "ALL";
    const HIDE_ALL_ENTRIES = "NONE";
    const MENU_TARGET_SELECTOR = "apex-action-button";
    const MENU_TARGET_TYPE_BTN = "BUTTON";
    const MENU_TARGET_TYPE_ACT = "APEX-ACTION-BUTTON";
    const TYPE_INLINE_BUTTON_NAMED = "NAMED";
    const UT_THEME_NUMBER = 42;
    const MENU_TITLE_DEFAULT = "Actions Menu";
    let affectedElements = daContext.affectedElements.get();
    if (!affectedElements.length) {
      apex.debug.error("Redwood - Action Menu - Error: Affected Element(s) cannot be found.");
      return;
    }
    let ajaxId = config.ajaxId;
    let menuIcon = config.menuIcon || (config.buttonTemplates.theme === UT_THEME_NUMBER ? ICON_UT_MENU : ICON_RW_MENU);
    let menuLabel = config.menuLabel;
    let items = config.items;
    let actionButtons = getActionButtons(items);
    let firstLevelActionButtons = items.filter((item) => item.items.length === 0 && item.href !== MENU_ITEM_TYPE_SEPARATOR);
    let buttonCSS = config.buttonCSS;
    let menuButtonTemplate = config.buttonTemplates.icon;
    let inlineButtonTemplate = config.buttonTemplates?.button || menuButtonTemplate;
    let iconType = menuButtonTemplate.iconType;
    let enableInlineButtons = config.inlineButtons;
    let enabledBtnsFirst = config.enabledButtonsFirst;
    let hideDisabled = config.hideDisabled;
    let targetSelector = config.targetSelector || MENU_TARGET_SELECTOR;
    let inlineButtonNames = config.inlineButtonNames ? config.inlineButtonNames.split(":") : [];
    let maxNumOfButtons = config.maxNumOfButtons;
    let maxInlineButtons = !maxNumOfButtons ? items.length : getMaxNumOfInlineButtons();
    let menuFilters = config.menuFilters;
    let menuId = `${config.daId}_menu`;
    let menuEl = $(`#${menuId}`);
    let menuBtn;
    let el$;
    let targetType;
    affectedElements.forEach((el, idx) => {
      el$ = $(el);
      targetType = el.nodeName;
      if (targetType === MENU_TARGET_TYPE_BTN && el$.attr(DATA_ATTR_BTN_MENU)) {
        return;
      }
      if (menuEl.length < 1 && (!enableInlineButtons || enableInlineButtons && (maxInlineButtons < firstLevelActionButtons.length || actionButtons.length > firstLevelActionButtons.length))) {
        menuEl = createMenu();
      }
      switch (targetType) {
        case MENU_TARGET_TYPE_ACT:
          replaceWithMenuButton(el$, idx);
          break;
        case MENU_TARGET_TYPE_BTN:
          handleAffectedButton(el$, idx);
          break;
        default:
          processRows(el$, idx);
      }
    });
    function getDataFromElement(el$2, idx) {
      let menuFilter = el$2.attr(DATA_MENU_FILTER) || menuFilters || checkOnClickHandler(el$2, DATA_MENU_FILTER);
      if (menuFilter) {
        menuFilter = unescape(menuFilter).split(":");
      } else {
        menuFilter = [SHOW_ALL_ENTRIES];
      }
      let elId = el$2.attr("id");
      let pkValue = el$2.attr(DATA_MENU_ID) || elId;
      let checksum = el$2.attr(DATA_MENU_ID_CHECKSUM);
      if (!pkValue) {
        pkValue = checkOnClickHandler(el$2, DATA_MENU_ID) || createButtonId(idx);
        el$2.attr(DATA_MENU_ID, pkValue);
      }
      let elementData = {};
      Object.assign(elementData, el$2[0].dataset);
      delete elementData[DATASET_MENU_ID];
      delete elementData[DATASET_MENU_FILTER];
      return { menuFilter, pkValue, elementData, elId, checksum };
    }
    function checkOnClickHandler(el$2, key) {
      let content = el$2.attr("onclick");
      if (!content?.includes(`${key}=`)) {
        return;
      }
      let regex = `${key}="(?<value>.*?)"`;
      let attr = content.match(regex);
      if (!attr?.groups?.value) {
        return;
      }
      let value = attr.groups.value;
      return value ? value.replaceAll('"', "") : false;
    }
    function processRows(containerEl, id) {
      let elId;
      let rows = $(`.${CLS_PLUGIN}`, containerEl);
      if (!rows.length) {
        rows = $(targetSelector, containerEl);
      }
      if (!rows.length) {
        rows = $(`[${DATA_MENU_ID}]`, containerEl);
      }
      rows.each((idx, el) => {
        elId = `${idx}-${id}`;
        handleAffectedButton($(el), elId);
      });
      $(window).trigger("apexwindowresized");
    }
    function handleAffectedButton(el$2, id) {
      let targetType2 = el$2[0].nodeName;
      if (targetType2 !== "BUTTON" || el$2[0].hasAttribute(DATA_ATTR_INLINE_BTN) || enableInlineButtons) {
        replaceWithMenuButton(el$2, id);
      } else {
        attachMenu(el$2, id);
      }
    }
    function addTitleAttr(el$2, button) {
      if (!el$2.attr("title")) {
        let labelText = el$2.find(".rw-Button-text").text();
        labelText = ["undefined", " ", "null", ""].includes(labelText) ? MENU_TITLE_DEFAULT : labelText;
        button ? button.attr("title", labelText) : el$2.attr("title", labelText);
      }
    }
    function attachMenu(el$2, idx) {
      let { menuFilter, pkValue } = getDataFromElement(el$2, idx);
      el$2.data("actions", menuFilter);
      if (hasValidChild(pkValue, menuEl.data().apexMenu.options.items, [], el$2)) {
        el$2.attr("disabled", false);
      } else if (menuFilter[0] === HIDE_ALL_ENTRIES) {
        el$2.attr("disabled", true);
      }
      el$2.removeAttr("onclick");
      el$2.attr({
        "type": "button",
        [DATA_ATTR_BTN_MENU]: menuId
      });
      el$2.addClass(`${CLS_JS_MENU_BUTTON} ${buttonCSS || ""}`);
      addTitleAttr(el$2);
    }
    function replaceWithMenuButton(el$2, idx) {
      let isMenuDisabled;
      let menuButton;
      let { menuFilter, pkValue, elementData, elId, checksum } = getDataFromElement(el$2, idx);
      if (menuFilter[0] === HIDE_ALL_ENTRIES) {
        menuButton = createMenuButton(pkValue, checksum);
        menuButton.attr({ "disabled": true, "id": elId });
        if (config.hideDisabledMenu) {
          menuButton.hide();
        }
        el$2.replaceWith(menuButton);
        return;
      }
      menuButton = createMenuButton(pkValue);
      menuButton.data("actions", menuFilter);
      menuButton.attr("id", elId);
      addTitleAttr(el$2, menuButton);
      Object.assign(menuButton[0].dataset, elementData);
      let dataInlineButtons = el$2.attr(DATA_ATTR_INLINE_BTN);
      if (dataInlineButtons) {
        dataInlineButtons = unescape(dataInlineButtons).split(":");
      } else {
        dataInlineButtons = inlineButtonNames;
      }
      if (enableInlineButtons || dataInlineButtons.length) {
        if (enabledBtnsFirst) {
          firstLevelActionButtons.sort((a, b) => {
            let aValid = isActionAllowed(a.action, menuFilter);
            let bValid = isActionAllowed(b.action, menuFilter);
            if (aValid && !bValid) {
              return 1;
            }
            if (!aValid && bValid) {
              return -1;
            }
            return 0;
          });
        }
        let inlineButtons = createInlineButtons(pkValue, dataInlineButtons, menuFilter, checksum);
        if (inlineButtons.addedButtons.length < actionButtons.length && maxNumOfButtons !== SHOW_ALL_ENTRIES) {
          if (hideDisabled && menuFilter[0] !== SHOW_ALL_ENTRIES) {
            isMenuDisabled = !actionButtons.some((value) => {
              return menuFilter.indexOf(value.action) > -1 && inlineButtons.addedButtons.indexOf(value.action) < 0;
            });
            menuButton.attr("disabled", isMenuDisabled);
            if (isMenuDisabled && config.hideDisabledMenu) {
              menuButton.hide();
            } else {
              menuButton.show();
            }
          }
          inlineButtons.buttonsContainer.append(menuButton);
        }
        el$2.replaceWith(inlineButtons.buttonsContainer);
        return;
      }
      isMenuDisabled = menuFilter[0] !== SHOW_ALL_ENTRIES;
      if (isMenuDisabled) {
        isMenuDisabled = !actionButtons.some((value) => {
          return menuFilter.indexOf(value.action) > -1;
        });
      }
      menuButton.attr("disabled", isMenuDisabled);
      if (isMenuDisabled && config.hideDisabledMenu) {
        menuButton.hide();
      } else {
        menuButton.show();
      }
      el$2.replaceWith(menuButton);
    }
    function isActionAllowed(action, filters) {
      if (!filters) {
        return true;
      }
      if (filters[0] === SHOW_ALL_ENTRIES) {
        return false;
      }
      return !filters.includes(action);
    }
    function createInlineButtons(pkValue, inlineButtonsList, filters, checksum) {
      let addedButtons = [];
      let btnDisabled;
      let btnEl;
      let buttonsContainer = $("<span></span>");
      let buttonsList = inlineButtonsList.length ? inlineButtonsList : firstLevelActionButtons;
      for (let i = 0; i < buttonsList.length; i++) {
        if (addedButtons.length >= maxInlineButtons) {
          break;
        }
        let item = buttonsList[i];
        if (typeof item === "string") {
          item = actionButtons.find((btn) => btn.action === buttonsList[i]);
          if (!item) {
            continue;
          }
        }
        btnDisabled = isActionAllowed(item.action, filters);
        if (hideDisabled && btnDisabled) {
          continue;
        }
        addedButtons.push(item.action);
        btnEl = createButton(item.label, item.icon, inlineButtonTemplate);
        btnEl = setInlineButtonAttributes(btnEl, pkValue, btnDisabled, item, checksum);
        buttonsContainer.append(btnEl);
      }
      return { addedButtons, buttonsContainer };
    }
    function setInlineButtonAttributes(btn, pkValue, isDisabled, item, checksum) {
      btn.attr({
        "disabled": isDisabled,
        "title": item.tooltip,
        [DATA_MENU_ID]: pkValue,
        [DATA_ATTR_ACTION_NAME]: item.action,
        [DATA_MENU_ID_CHECKSUM]: checksum
      });
      btn.addClass(item.buttonClass);
      let triggeringElement = daContext.action.affectedRegionId ? $(`#${daContext.action.affectedRegionId}`) : btn;
      btn.on("click", () => {
        invokeAction.call(btn, item, triggeringElement);
      });
      btn.removeAttr(DATA_ATTR_BTN_MENU);
      return btn;
    }
    function createButtonId(idx) {
      return `${config.daId}--button-${idx}`;
    }
    function createButton(btnLabel, btnIcon, buttonTemplate) {
      let { btnClass, template, icon } = buttonTemplate;
      let btn = apex.util.applyTemplate(template.replace(/#(\w+)?!(ATTR|JS|RAW|HTML|STRIPHTML)#/g, "&$1!$2."), {
        "placeholders": {
          "BUTTON_CSS_CLASSES": `${btnClass || ""}`,
          "ICON_CSS_CLASSES": `${iconType || ""} ${btnIcon || icon}`,
          "BUTTON_ATTRIBUTES": `${DATA_MENU_ID} ${DATA_ATTR_BTN_MENU} ${DATA_MENU_ID_CHECKSUM}`,
          "LABEL": btnLabel || ""
        },
        "extraSubstitutions": {
          "LABEL": btnLabel || ""
        }
      });
      let btn$ = $(btn);
      btn$.removeAttr("id onclick");
      return btn$;
    }
    function createMenuButton(itemId, checksum) {
      let clone;
      if (!menuBtn) {
        menuBtn = createButton(menuLabel, menuIcon, menuButtonTemplate).addClass(`${CLS_JS_MENU_BUTTON} ${buttonCSS || ""}`);
      }
      clone = menuBtn.clone();
      clone.attr({
        [DATA_MENU_ID]: itemId || "",
        [DATA_ATTR_BTN_MENU]: menuId,
        [DATA_MENU_ID_CHECKSUM]: checksum
      });
      return clone;
    }
    function createMenu() {
      let rowActionMenu$ = $("<div/>", {
        id: menuId
      }).appendTo("body");
      let lRowActionMenuItems = items.map(createMenuItem);
      rowActionMenu$.menu({
        iconType,
        items: lRowActionMenuItems,
        beforeOpen: function(event, ui) {
          let pkValue = getPkFromMenuEntry();
          let activeMenuBtn$ = getActiveMenuButton();
          let rowInlineButtonsList = [];
          activeMenuBtn$.siblings().each((idx, button) => {
            if (button.hasAttribute(DATA_ATTR_ACTION_NAME)) {
              rowInlineButtonsList.push($(button).attr(DATA_ATTR_ACTION_NAME));
            }
          });
          ui.menu.items.forEach((item) => {
            setItemState(pkValue, rowInlineButtonsList, item, activeMenuBtn$);
          });
        }
      });
      return rowActionMenu$;
    }
    function setItemState(pkValue, inlineButtonsList, item, el$2) {
      let menu = item.menu;
      if (item.type === MENU_ITEM_TYPE_ACTION) {
        let actions = getActiveMenuButton().data().actions;
        if (actions[0] && actions[0] === SHOW_ALL_ENTRIES) {
          item.disabled = false;
        } else {
          item.disabled = !actions.includes(item.id);
        }
        item.hide = inlineButtonsList.includes(item.id) ? true : hideDisabled ? item.disabled : false;
      } else if (item.type === MENU_ITEM_TYPE_MENU) {
        let isValidMenu = !hasValidChild(pkValue, menu.items, inlineButtonsList, el$2);
        if (hideDisabled) {
          item.hide = isValidMenu;
        }
      }
      if (!item.disabled && !item.hide && menu?.items.length > 0) {
        menu.items = menu.items.map((item2) => setItemState(pkValue, inlineButtonsList, item2, el$2));
      }
      return item;
    }
    function isEntryDisabled(id, actionName, el$2) {
      let btn$ = el$2 || $(`#${id}.${CLS_JS_MENU_BUTTON}`);
      if (btn$.length) {
        let actions = btn$.data()?.actions;
        if (actions) {
          return !(actions[0] === SHOW_ALL_ENTRIES || actions.includes(actionName));
        }
      }
      return false;
    }
    function getActiveMenuButton() {
      return $(`.${CLS_JS_MENU_BUTTON}.${CLS_IS_ACTIVE}`);
    }
    function getPkFromMenuEntry() {
      let menuButton$ = getActiveMenuButton();
      return menuButton$.attr(DATA_MENU_ID) || menuButton$.attr("id");
    }
    function getPkChecksumFromMenuEntry() {
      let menuButton$ = getActiveMenuButton();
      return menuButton$.attr(DATA_MENU_ID_CHECKSUM);
    }
    function raiseError(message, data) {
      message = "Redwood - Action Menu - Error: " + message;
      apex.debug.error(message, data);
      if (!config.suppressErrorNotification) {
        apex.message.showErrors({
          type: "error",
          location: ["page"],
          pageItem: void 0,
          message,
          unsafe: false
        });
      }
      apex.event.trigger(daContext.affectedElements[0], "apex-actions-menu-error", {
        "message": message,
        "data": data
      });
    }
    function openLink(newTab, link) {
      if (newTab) {
        apex.navigation.openInNewWindow(link);
      } else {
        apex.navigation.redirect(link);
      }
    }
    function createMenuItem(item) {
      let itemObj = {
        "id": item.action,
        "href": item.href,
        "icon": item.icon,
        "label": item.label,
        "items": item.items
      };
      if (item.href === MENU_ITEM_TYPE_SEPARATOR) {
        itemObj.type = MENU_ITEM_TYPE_SEPARATOR;
      } else if (item.items?.length > 0) {
        itemObj.type = MENU_ITEM_TYPE_MENU;
        itemObj.items = itemObj.items.map(createMenuItem);
        itemObj.menu = { items: itemObj.items };
      } else {
        itemObj.type = MENU_ITEM_TYPE_ACTION;
        let triggeringElement = $(`#${daContext.action.affectedRegionId}`);
        itemObj.action = function() {
          invokeAction(item, triggeringElement);
        };
      }
      delete itemObj.items;
      return itemObj;
    }
    function invokeAction(item, triggeringElement) {
      let pkValue = getPkFromMenuEntry() || $(this).attr(DATA_MENU_ID);
      let checksum = getPkChecksumFromMenuEntry() || $(this).attr(DATA_MENU_ID_CHECKSUM);
      if (!pkValue) {
        raiseError("Primary Key value cannot be found.", item);
        return;
      }
      let activeButton = getActiveMenuButton();
      if (!activeButton.length && this[0] && this[0].nodeName === MENU_TARGET_TYPE_BTN) {
        activeButton = this[0];
      }
      if (!triggeringElement.length) {
        triggeringElement = activeButton;
      }
      let data = { id: pkValue, action: item.action, button: activeButton };
      Object.assign(data, activeButton.dataset || activeButton[0].dataset);
      if (item.action) {
        if (apex.actions.lookup(item.action)) {
          apex.actions.invoke(item.action, null, triggeringElement, data);
        }
      }
      if (item.actionEvent) {
        apex.event.trigger(triggeringElement, item.actionEvent, data);
      }
      if (item.actionFunction) {
        item.actionFunction.call({ data });
      }
      if (item.href) {
        if (!item.prepareURL) {
          openLink(item.newTab, apex.util.applyTemplate(item.href, {placeholders:{"ID": pkValue }}));
        } else {
          let result = apex.server.plugin(ajaxId, {
            x01: pkValue,
            x02: item.action,
            x03: checksum
          });
          result.done((data2) => {
            if (data2.success) {
              openLink(item.newTab, data2.url);
            } else {
              raiseError(data2.message, data2);
            }
          }).fail((jqXHR, textStatus) => {
            raiseError(textStatus, data);
          });
        }
      }
    }
    function getActionButtons(items2) {
      let result = [];
      for (let i = 0; i < items2.length; i++) {
        let item = items2[i];
        if (item.href === MENU_ITEM_TYPE_SEPARATOR) {
          continue;
        }
        if (item.items.length > 0) {
          result = [...result, ...getActionButtons(item.items)];
        } else {
          result.push(item);
        }
      }
      return result;
    }
    function hasValidChild(pkValue, menuItem, menuInlineBtns, el$2) {
      let result = false;
      let item;
      let itemId;
      for (let i = 0; i < menuItem.length; i++) {
        item = menuItem[i];
        itemId = item.id || item.action;
        if (!isEntryDisabled(pkValue, itemId, el$2) && menuInlineBtns.indexOf(itemId) < 0 && actionButtons.some((btn) => btn.action === itemId)) {
          return true;
        } else if (item.type === MENU_ITEM_TYPE_MENU) {
          return hasValidChild(pkValue, item.menu.items, menuInlineBtns, el$2);
        }
      }
      return result;
    }
    function unescape(str) {
      return str.replaceAll("&#x3A;", ":");
    }
    function getMaxNumOfInlineButtons() {
      if (maxNumOfButtons === SHOW_ALL_ENTRIES) {
        return items.length;
      } else if (maxNumOfButtons === TYPE_INLINE_BUTTON_NAMED) {
        return inlineButtonNames.length;
      } else {
        return parseInt(maxNumOfButtons, 10);
      }
    }
    if (typeof daContext.resumeCallback === "function") {
      daContext.resumeCallback();
    }
  };
  return __toCommonJS(redwood_action_menu_exports);
})();
