var apex;
((apex ||= {}).redwood ||= {}).avatar = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/js/redwood.avatar.js
  var redwood_avatar_exports = {};
  __export(redwood_avatar_exports, {
    init: () => init
  });
  var init = (self, data) => {
    if (self.affectedElements.length === 0) {
      apex.debug.error("Component needs affected region", self);
      return;
    }
    const dataAttrPrefix = "data-rw-avatar";
    const $element = $(self.affectedElements).find(`[${dataAttrPrefix}]`).addBack(`[${dataAttrPrefix}]`);
    for (const [key, value] of Object.entries(data)) {
      if (key.startsWith("class")) {
        apex.debug.log("key:value", key, value);
        $element.addClass(value);
      } else if (key.startsWith("style")) {
        apex.debug.log("key:value", key, value);
        $element.attr("style", value);
      }
    }
    $element.text(data[`${dataAttrPrefix}-value`]);
  };
  return __toCommonJS(redwood_avatar_exports);
})();
