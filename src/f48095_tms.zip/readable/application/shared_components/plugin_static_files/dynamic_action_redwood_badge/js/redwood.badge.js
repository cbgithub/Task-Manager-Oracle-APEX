var apex;
((apex ||= {}).redwood ||= {}).badge = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/js/redwood.badge.js
  var redwood_badge_exports = {};
  __export(redwood_badge_exports, {
    init: () => init
  });
  var init = (self, data) => {
    if (self.affectedElements.length === 0) {
      apex.debug.error("Component needs affected region", self);
      return;
    }
    const dataAttrPrefix = "data-rw-badge";
    const dataKeys = {
      value: `${dataAttrPrefix}-value`,
      appearance: `${dataAttrPrefix}-appearance`,
      size: `${dataAttrPrefix}-size`,
      state: `${dataAttrPrefix}-state`,
      label: `${dataAttrPrefix}-label`,
      id: `${dataAttrPrefix}-id`
    };
    const $badge = $('<span class="rw-Badge"></span>');
    Object.entries(dataKeys).forEach(([key, attr]) => {
      if (data[attr]) {
        if (key === "label") {
          $badge.prop("title", data[attr]);
        } else if (key === "value") {
          $badge.text(data[attr]);
        } else {
          $badge.addClass(`rw-Badge--${data[attr]}`);
        }
      }
    });
    const $elements = $(self.affectedElements).find(`[${dataAttrPrefix}]`).addBack(`[${dataAttrPrefix}]`);
    $elements.each((index, element) => {
      const $element = $(element);
      const $currentBadge = $badge.clone();
      $currentBadge.attr("id", $element.attr(dataKeys.id));
      const badgePlacement = $element.data("rwBadge");
      if (badgePlacement === "append") {
        $element.append($currentBadge);
      } else if (badgePlacement === "prepend") {
        $element.prepend($currentBadge);
      } else {
        $element.replaceWith($currentBadge);
      }
    });
  };
  return __toCommonJS(redwood_badge_exports);
})();
