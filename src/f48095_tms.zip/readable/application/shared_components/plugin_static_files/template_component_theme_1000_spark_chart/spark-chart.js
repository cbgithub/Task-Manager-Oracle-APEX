require(["ojs/ojchart"], function() {});
