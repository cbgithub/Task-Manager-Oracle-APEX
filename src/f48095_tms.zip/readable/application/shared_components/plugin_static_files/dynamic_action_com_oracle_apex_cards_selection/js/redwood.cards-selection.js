var apex;
((apex ||= {}).redwood ||= {}).cardSelection = (() => {
  var __defProp = Object.defineProperty;
  var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
  var __getOwnPropNames = Object.getOwnPropertyNames;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __export = (target, all) => {
    for (var name in all)
      __defProp(target, name, { get: all[name], enumerable: true });
  };
  var __copyProps = (to, from, except, desc) => {
    if (from && typeof from === "object" || typeof from === "function") {
      for (let key of __getOwnPropNames(from))
        if (!__hasOwnProp.call(to, key) && key !== except)
          __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
    }
    return to;
  };
  var __toCommonJS = (mod) => __copyProps(__defProp({}, "__esModule", { value: true }), mod);

  // src/js/redwood.cards-selection.js
  var redwood_cards_selection_exports = {};
  __export(redwood_cards_selection_exports, {
    cancelSelect: () => cancelSelect,
    deselect: () => deselect,
    disableSelection: () => disableSelection,
    getSelectedCardId: () => getSelectedCardId,
    init: () => init,
    isSelectionDisabled: () => isSelectionDisabled,
    select: () => select,
    selectFirst: () => selectFirst,
    selectLast: () => selectLast,
    selectNext: () => selectNext,
    selectPrev: () => selectPrev
  });
  var Key = Object.freeze({
    LEFT: 37,
    UP: 38,
    RIGHT: 39,
    DOWN: 40,
    RETURN: 13,
    ENTER: 13,
    SPACE: 32
  });
  var SelectionEvent = deepFreeze({
    BEFORE_SELECT: {
      name: "cards_selection_before_select",
      cancelable: true
    },
    AFTER_SELECT: {
      name: "cards_selection_after_select"
    },
    AFTER_DESELECT: {
      name: "cards_selection_after_deselect"
    }
  });
  var DA_NAME = "APEX Cards Selection";
  var CARD_SELECTOR = ".a-CardView-item, .rw-Card, .rw-ListItem";
  var CLS_CONVEYOR_BELT = "rw-ConveyorBelt";
  var CLS_ACTIVE_CARD = "is-focused";
  var CLS_SELECTED_CARD = "is-selected";
  var CLS_SELECTION_MARKER = "card-selection-marker";
  var CLS_CARD_CONTAINER = "a-TMV-body";
  var SELECTOR_CARD_CONTAINER = `.${CLS_CARD_CONTAINER}`;
  var SELECTOR_CONVEYOR_BELT_CONTAINER = ".rw-ConveyorBelt-container";
  var DEFAULT_PRIMARY_KEY_SEPARATOR = ":";
  var init = function(daContext, config) {
    apex.debug.info(DA_NAME, config, daContext);
    let selectionPageItem = config.targetItem ? apex.item(config.targetItem) : null;
    callOnAffected(daContext, initRegion);
    function initRegion(regionEl) {
      let cardsContainerEl;
      let selectedCardEl;
      let selectedCardIndex;
      let selectedId = "";
      let focusedCardEl;
      let focusedCardIndex = -1;
      let allCardEls = [];
      let regionId = regionEl.id;
      let region = apex.region(regionId);
      let selectOnFocus = config.selectionFollowsFocus;
      let allowDeselect = config.allowDeselect;
      let allowCycling = config.allowCycling;
      let retainSelection = config.retainSelection;
      let selectedCssCls = config.cssClass && config.cssClass.split(" ");
      let afterLoadSelectFirst = config.selectFirst;
      let disabled = false;
      let conveyorBeltEl;
      let conveyorBeltContainerEl;
      let primaryKeySeparator = config.pkSeparator ?? DEFAULT_PRIMARY_KEY_SEPARATOR;
      let isRedwood = config.theme !== 42;
      let contentMutationObserver;
      let conveyorBeltObserver;
      if (selectionPageItem) {
        $(selectionPageItem.node).on("change", () => {
          let id = selectionPageItem.getValue();
          let res;
          if (id !== selectedId) {
            res = selectId(id);
            if (!res) {
              if (allowDeselect) {
                deselect2();
              } else {
                selectionPageItem.setValue(selectedId);
              }
            }
          }
        });
      }
      region.on("tablemodelviewpagechange", () => {
        if (!isRedwood) {
          setUpContainer(regionEl.querySelector(SELECTOR_CARD_CONTAINER));
        }
        afterRefresh();
      });
      if (isRedwood) {
        contentMutationObserver = new MutationObserver((mutationList) => {
          mutationList.forEach((mutation) => {
            mutation.removedNodes.forEach((node) => {
              if (node.nodeType === Node.ELEMENT_NODE) {
                let clsList = node.classList;
                if (clsList.contains(CLS_CARD_CONTAINER)) {
                  destroyContainer();
                } else if (clsList.contains(CLS_CONVEYOR_BELT)) {
                  destroyConveyorBelt;
                }
              }
            });
            mutation.addedNodes.forEach((node) => {
              if (node.nodeType === Node.ELEMENT_NODE) {
                let clsList = node.classList;
                if (clsList.contains(CLS_CARD_CONTAINER)) {
                  setUpContainer(node);
                  afterRefresh();
                } else if (clsList.contains(CLS_CONVEYOR_BELT)) {
                  setUpConveyorBelt(node);
                }
              }
            });
          });
        });
        contentMutationObserver.observe(regionEl.querySelector(".a-TMV--cards"), { subtree: true, childList: true });
        conveyorBeltObserver = new MutationObserver((mutationList) => {
          mutationList.forEach((mutation) => {
            if (mutation.attributeName === "tabindex" && mutation.target.getAttribute("tabindex") >= 0) {
              mutation.target.setAttribute("tabindex", -1);
            }
          });
        });
      }
      function setUpContainer(node) {
        cardsContainerEl = node;
        let cardsContainerTabIndex = cardsContainerEl.getAttribute("tabindex");
        if (cardsContainerTabIndex === null || cardsContainerTabIndex < 0) {
          cardsContainerEl.setAttribute("tabindex", 0);
        }
        cardsContainerEl.addEventListener("focus", cardsContainerFocusHandler);
        cardsContainerEl.addEventListener("focusout", cardsContainerFocusOutHandler);
        cardsContainerEl.addEventListener("click", cardsContainerClickHandler);
        cardsContainerEl.addEventListener("keydown", keyDownHandler);
      }
      function destroyContainer() {
        cardsContainerEl.removeEventListener("focus", cardsContainerFocusHandler);
        cardsContainerEl.removeEventListener("focusout", cardsContainerFocusOutHandler);
        cardsContainerEl.removeEventListener("click", cardsContainerClickHandler);
        cardsContainerEl.removeEventListener("keydown", keyDownHandler);
      }
      function setUpConveyorBelt(node) {
        conveyorBeltEl = node;
        conveyorBeltEl.setAttribute("tabindex", -1);
        conveyorBeltContainerEl = node.querySelector(SELECTOR_CONVEYOR_BELT_CONTAINER);
        conveyorBeltObserver.observe(conveyorBeltEl, { attributes: true });
        if (selectedCardEl) {
          ensureVisible(conveyorBeltContainerEl, selectedCardEl);
        }
      }
      function destroyConveyorBelt() {
        conveyorBeltObserver.disconnect();
        conveyorBeltEl = conveyorBeltContainerEl = null;
      }
      function afterRefresh() {
        prepareCards();
        if (retainSelection) {
          if (selectedId === "" && selectionPageItem) {
            let v = selectionPageItem.getValue();
            if (v !== null) {
              selectedId = v;
            }
          }
          if (isIdInCurrentSet(selectedId)) {
            selectId(selectedId);
          } else if (afterLoadSelectFirst) {
            select2(0);
          } else {
            deselect2(true);
          }
        } else if (afterLoadSelectFirst) {
          select2(0);
        } else {
          deselect2(true);
        }
      }
      Object.assign(region, {
        selectFirstCard() {
          select2(0);
        },
        selectLastCard() {
          select2(allCardEls.length - 1);
        },
        deselectCard() {
          deselect2();
        },
        selectNextCard() {
          let index = (selectedCardIndex ?? -1) + 1;
          let len = allCardEls.length;
          if (index >= len) {
            index = allowCycling ? 0 : len - 1;
          } else if (index < 0) {
            index = allowCycling ? len - 1 : 0;
          }
          select2(index);
        },
        selectPrevCard() {
          let index = (selectedCardIndex ?? 1) - 1;
          let len = allCardEls.length;
          if (index >= len) {
            index = allowCycling ? 0 : len - 1;
          } else if (index < 0) {
            index = allowCycling ? len - 1 : 0;
          }
          select2(index);
        },
        selectCard(id) {
          let el = getCardElById(apex.util.applyTemplate(id));
          el && select2(el);
        },
        cancelCardSelect(data) {
          cancelSelect2(data);
        },
        disableSelection: disableSelection2,
        isSelectionDisabled: isSelectionDisabled2,
        getSelectedCardId: getSelectedCardId2,
        getCardElById
      });
      try {
        setUpContainer(regionEl.querySelector(SELECTOR_CARD_CONTAINER));
        afterRefresh();
      } catch (e) {
      }
      function getIdByCardIndex(index) {
        let model = region.getModel();
        let view = region.widget().data().apexTableModelView;
        let pageOffset = view.options?.pagination?.scroll ? 0 : view.pageOffset;
        let pk = model._getPrimaryKey(model._data[index + pageOffset]);
        if (pk != null) {
          if (Array.isArray(pk)) {
            pk = pk.join(primaryKeySeparator);
          }
          return pk;
        }
        throw new Error(`Region ${regionId} does not have a PK column set.`);
      }
      function getCardElById(id) {
        let cardEl = allCardEls.find((el) => el.dataset.id === id);
        if (cardEl) {
          return cardEl;
        }
        id = id.split(primaryKeySeparator);
        let model = region.getModel();
        let data = model._data;
        let record = model._getRecordById(id);
        let view = region.widget().data().apexTableModelView;
        let pageOffset = view.options?.pagination?.scroll ? 0 : view.pageOffset;
        if (record) {
          let index = data.findIndex((rec) => rec === record);
          if (index > -1) {
            return allCardEls[index - pageOffset];
          }
        }
      }
      function selectId(id) {
        if (id !== null) {
          let cardEl = getCardElById(id);
          if (cardEl) {
            select2(cardEl);
            return true;
          }
        }
        return false;
      }
      function isIdInCurrentSet(id) {
        return !!getCardElById(id);
      }
      function cardsContainerClickHandler(e) {
        let clickedEl = e.target;
        let cardEl = clickedEl.closest(CARD_SELECTOR);
        cardsContainerEl.setAttribute("tabindex", -1);
        if (cardEl) {
          setActiveCard(cardEl);
          toggleSelect(cardEl);
        }
      }
      function cardsContainerFocusHandler() {
        if (!focusedCardEl) {
          selectedCardEl ? setActiveCard(selectedCardEl) : setActiveCard(0);
          cardsContainerEl.setAttribute("tabindex", -1);
        }
      }
      function cardsContainerFocusOutHandler(e) {
        if (!cardsContainerEl.contains(e.relatedTarget)) {
          setActiveCard(-1);
          cardsContainerEl.setAttribute("tabindex", 0);
        }
      }
      function prepareCards() {
        let tabIndex;
        if (!cardsContainerEl) {
          return;
        }
        allCardEls = Array.from(cardsContainerEl.querySelectorAll(CARD_SELECTOR));
        allCardEls.forEach((cardEl) => {
          tabIndex = cardEl.getAttribute("tabindex");
          if (tabIndex !== null) {
            cardEl.dataset.oriTabindex = tabIndex;
          }
          cardEl.setAttribute("tabindex", -1);
          cardEl.querySelectorAll("a, button").forEach((el) => {
            tabIndex = el.getAttribute("tabindex");
            if (tabIndex !== null) {
              el.dataset.oriTabindex = tabIndex;
            }
            el.setAttribute("tabindex", -1);
          });
          let firstEl = cardEl.firstElementChild;
          if (!firstEl.classList.contains(CLS_SELECTION_MARKER)) {
            cardEl.insertAdjacentHTML("afterbegin", `<div class="${CLS_SELECTION_MARKER}"/>`);
          }
        });
      }
      function keyDownHandler(e) {
        let pd = e.preventDefault.bind(e);
        switch (e.keyCode) {
          case Key.RIGHT:
          case Key.DOWN:
            pd();
            cycleCards(1);
            if (selectOnFocus) {
              select2(focusedCardIndex);
            }
            break;
          case Key.LEFT:
          case Key.UP:
            pd();
            cycleCards(-1);
            if (selectOnFocus) {
              select2(focusedCardIndex);
            }
            break;
          case Key.SPACE:
            pd();
            toggleSelect(focusedCardIndex);
            break;
          case Key.ENTER:
            pd();
            toggleSelect(focusedCardIndex);
            break;
        }
      }
      function cycleCards(dir) {
        let len = allCardEls.length;
        let step = dir < 0 ? -1 : 1;
        if (!step || !len) {
          return;
        }
        let index = focusedCardIndex + step;
        if (index >= len) {
          if (!allowCycling) {
            return;
          }
          index = 0;
        } else if (index < 0) {
          if (!allowCycling) {
            return;
          }
          index = len - 1;
        }
        setActiveCard(index);
      }
      function setActiveCard(card) {
        let len = allCardEls.length;
        let index = typeof card === "number" ? card : allCardEls.findIndex((el) => el === card);
        let inRange = index >= 0 && index < len;
        let cardEl = inRange ? allCardEls[index] : null;
        if (focusedCardEl && focusedCardEl !== cardEl) {
          focusedCardEl.classList.remove(CLS_ACTIVE_CARD);
        }
        if (inRange) {
          focusedCardIndex = index;
          focusedCardEl = cardEl;
          focusedCardEl.classList.add(CLS_ACTIVE_CARD);
          if (conveyorBeltContainerEl && !selectOnFocus) {
            ensureVisible(conveyorBeltContainerEl, focusedCardEl);
          }
          focusedCardEl.focus();
        } else {
          focusedCardIndex = -1;
          focusedCardEl = null;
        }
      }
      function toggleSelect(card) {
        let index = typeof card === "number" ? card : allCardEls.findIndex((el) => el === card);
        if (selectedCardIndex === index) {
          deselect2();
        } else {
          select2(index);
        }
      }
      function select2(card) {
        let index = typeof card === "number" ? card : allCardEls.findIndex((el) => el === card);
        let prevSelectedId = selectedId;
        if (disabled || index < 0 || index >= allCardEls.length) {
          return;
        }
        let cardEl = allCardEls[index];
        let cardId = getIdByCardIndex(index);
        if (cardEl === selectedCardEl) {
          if (conveyorBeltContainerEl) {
            ensureVisible(conveyorBeltContainerEl, selectedCardEl);
          }
          return;
        }
        if (cardId !== prevSelectedId) {
          if (triggerEvent(SelectionEvent.BEFORE_SELECT, { id: cardId }) === false) {
            return;
          }
          deselect2(true, true);
          selectedId = cardId;
          if (selectionPageItem) {
            selectionPageItem.setValue(selectedId);
          }
        }
        selectedCardIndex = index;
        selectedCardEl = cardEl;
        cardEl.classList.add(CLS_SELECTED_CARD);
        if (selectedCssCls) {
          cardEl.classList.add(...selectedCssCls);
        }
        if (conveyorBeltContainerEl) {
          ensureVisible(conveyorBeltContainerEl, cardEl);
        }
        if (selectedId !== prevSelectedId) {
          triggerEvent(SelectionEvent.AFTER_SELECT, { id: cardId });
        }
      }
      function deselect2(force = false, suppressPageItemUpdate = false) {
        if (!disabled && selectedCardEl && (allowDeselect || force)) {
          let el = selectedCardEl;
          el.classList.remove(CLS_SELECTED_CARD);
          if (selectedCssCls) {
            el.classList.remove(...selectedCssCls);
          }
          let eventData = {
            id: selectedId
          };
          resetSelection();
          if (selectionPageItem && !suppressPageItemUpdate) {
            selectionPageItem.setValue("");
          }
          triggerEvent(SelectionEvent.AFTER_DESELECT, eventData);
        }
      }
      function cancelSelect2(data = {}) {
        data.cancelEvent = true;
      }
      function resetSelection(keepId = false) {
        selectedCardEl = null;
        selectedCardIndex = -1;
        if (!keepId) {
          selectedId = "";
        }
      }
      function triggerEvent(event, data) {
        let cancelable = event.cancelable;
        if (cancelable) {
          data.cancelEvent = false;
        }
        apex.event.trigger(region.element, event.name, data);
        if (cancelable) {
          return !data.cancelEvent;
        }
      }
      function disableSelection2(bool) {
        disabled = !!bool;
      }
      function isSelectionDisabled2() {
        return disabled;
      }
      function getSelectedCardId2() {
        return selectedId;
      }
    }
  };
  function callOnAffected(daContext, fn) {
    let affectedElements = daContext.affectedElements.length && daContext.affectedElements.get();
    if (!affectedElements) {
      apex.debug.error(`Redwood - ${DA_NAME} - Error: Affected Element(s) cannot be found.`);
      return null;
    }
    affectedElements.forEach(fn);
    return affectedElements;
  }
  function deepFreeze(obj) {
    Object.keys(obj).forEach((prop) => {
      if (typeof obj[prop] === "object" && !Object.isFrozen(obj[prop])) {
        deepFreeze(obj[prop]);
      }
    });
    return Object.freeze(obj);
  }
  function ensureVisible(container, element) {
    let contLeft = container.scrollLeft;
    let contRight = contLeft + container.clientWidth;
    let elLeft = element.offsetLeft;
    let elRight = elLeft + element.clientWidth;
    if (elLeft < contLeft) {
      container.scrollLeft -= contLeft - elLeft;
    } else if (elRight > contRight) {
      container.scrollLeft += elRight - contRight;
    }
  }
  function extendNamespace(regionFn, daContext, config) {
    callOnAffected(daContext, fn);
    function fn(regionEl) {
      let region = apex.region(regionEl.id);
      if (region) {
        if (typeof region[regionFn] === "function") {
          region[regionFn](config);
        } else {
          apex.debug.error(`Redwood - ${DA_NAME} - Error: The method ${regionFn} does not exist on this region. (If this is a Card region, make sure to call "${DA_NAME} - initialize" on it first.)`);
        }
      } else {
        apex.debug.error(`Redwood - ${DA_NAME} - Error: Region ${regionEl.id} could not be found.`);
      }
    }
  }
  function select(daContext, config) {
    extendNamespace("selectCard", daContext, config);
  }
  function deselect(daContext, config) {
    extendNamespace("deselectCard", daContext, config);
  }
  function selectFirst(daContext, config) {
    extendNamespace("selectFirstCard", daContext, config);
  }
  function selectLast(daContext, config) {
    extendNamespace("selectLastCard", daContext, config);
  }
  function selectPrev(daContext, config) {
    extendNamespace("selectPrevCard", daContext, config);
  }
  function selectNext(daContext, config) {
    extendNamespace("selectNextCard", daContext, config);
  }
  function disableSelection(daContext, config) {
    extendNamespace("disableSelection", daContext, config);
  }
  function isSelectionDisabled(daContext, config) {
    extendNamespace("isSelectionDisabled", daContext, config);
  }
  function getSelectedCardId(daContext, config) {
    extendNamespace("getSelectedCardId", daContext, config);
  }
  function cancelSelect(daContext, config) {
    extendNamespace("cancelCardSelect", daContext, config);
  }
  return __toCommonJS(redwood_cards_selection_exports);
})();
