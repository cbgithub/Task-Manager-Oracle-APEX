create or replace package apex_actions_menu_plugin authid current_user 
as 
 
     -------------------------------------------------------------------------------- 
    -- Oracle 
    --  
    -- Actions Menu 
    --  
    -- This plug-in makes it possible to define action menu buttons in a simple 
    -- and declarative way using a predefined APEX list 
    -- 
    --------------------------------------------------------------------------------    
 
    --============================================================================== 
    -- secure data values, p_msg is in the form of {ID}|{ACTION1:ACTION2:ACTION3...} 
    --============================================================================== 
    function encode_with_checksum ( 
        p_msg  in varchar2 ) 
        return varchar2; 
 
    --============================================================================== 
    -- standard render function 
    --============================================================================== 
    function render ( 
        p_dynamic_action in apex_plugin.t_dynamic_action, 
        p_plugin         in apex_plugin.t_plugin ) 
        return apex_plugin.t_dynamic_action_render_result; 
 
    --============================================================================== 
    -- standard ajax function 
    --============================================================================== 
    function ajax ( 
        p_dynamic_action in apex_plugin.t_dynamic_action, 
        p_plugin         in apex_plugin.t_plugin ) 
        return apex_plugin.t_dynamic_action_ajax_result; 
 
end apex_actions_menu_plugin;
/
create or replace package body apex_actions_menu_plugin 
as 
     -------------------------------------------------------------------------------- 
    -- Oracle 
    --  
    -- Actions Menu 
    --  
    -- This plug-in makes it possible to define action menu buttons in a simple 
    -- and declarative way using a predefined APEX list 
    -- 
    -------------------------------------------------------------------------------- 
    --============================================================================== 
    type t_list_row is record ( 
        id             varchar2(255), 
        list_type_code varchar2(255), 
        list_query     varchar2(32767) ); 
    --============================================================================== 
    type t_menu_option is record ( 
        level             pls_integer, 
        label             varchar2(255), 
        href              varchar2(4000), 
        icon              varchar2(255), 
        action            varchar2(255), 
        action_event      varchar2(255), 
        action_function   varchar2(4000), 
        prepare_url       varchar2(255), 
        new_tab           varchar2(255), 
        button_class      varchar2(255), 
        tooltip           varchar2(1000) ); 
    --============================================================================== 
    c_encode_from_chars     constant varchar2(5)        := unistr('\000a\000d+/='); 
    c_encode_to_chars       constant varchar2(5)        := ',.-_'; 
    c_decode_from_chars     constant varchar2(5)        := ',.-_~'; 
    c_decode_to_chars       constant varchar2(5)        := unistr('\000a\000d+/'); 
    c_g_pk_value_subst      constant varchar2(10)       := '#ID#'; 
    c_g_package_prefix      constant varchar2(255)      := 'apex_actions_menu_plugin.'; 
    c_g_app_id              constant number             := nvl(apex_application.g_translated_flow_id, apex_application.g_flow_id); 
    c_g_page_id             constant number             := apex_application.g_flow_step_id; 
    g_region_id             number; 
 
    -- list type constants 
    subtype t_list_type is varchar2(100); 
    -- region type constants 
    subtype t_region_type is varchar2(100); 
 
    c_g_list_type_static    constant t_list_type    := 'STATIC'; 
    c_g_list_type_sql       constant t_list_type    := 'SQL_QUERY'; 
    c_g_list_type_plsql     constant t_list_type    := 'FUNCTION_RETURNING_SQL_QUERY'; 
    c_g_region_type_ir      constant t_region_type  := 'NATIVE_IR'; 
    c_g_region_type_rpt     constant t_region_type  := 'NATIVE_SQL_REPORT'; 
    --============================================================================== 
    -- this will ensure the checksum is localized to the region 
    --============================================================================== 
    function get_salt ( 
        p_region_id in number default null ) 
        return varchar2  
    is 
    begin 
        g_region_id  := case when p_region_id is null then apex_application.get_component().id else p_region_id end; 
        return apex_application.g_instance||g_region_id; 
    end get_salt; 
    --============================================================================== 
    -- encode the checksum in the form of {ID}|{ACTION1:ACTION2:ACTION3...} 
    --============================================================================== 
    function encode_with_checksum ( 
        p_msg  in varchar2 ) 
        return varchar2 
    is 
        l_msg    varchar2(32767); 
        l_result varchar2(32767); 
        l_salt   varchar2(255); 
    begin 
        l_salt := get_salt;
        if apex_application.g_debug then
            apex_debug.enter ( 
                c_g_package_prefix||'encode_with_checksum' , 
                'p_msg'                    , p_msg     , 
                'l_salt'                   , l_salt    , 
                'g_region_id'              , g_region_id );
        end if;
        if p_msg is not null then 
            l_msg := translate ( 
                         sys.utl_raw.cast_to_varchar2(sys.utl_encode.base64_encode(sys.utl_raw.cast_to_raw(p_msg))), 
                         c_encode_from_chars, 
                         c_encode_to_chars ); 
        end if; 
        l_result := l_msg|| 
                    '/'|| 
                    wwv_flow_utilities.lov_checksum ( 
                        p_string => l_msg||'/'||l_salt ); 
        return l_result; 
    end encode_with_checksum; 
    --============================================================================== 
    -- decode the checksum in the form of {ID}|{ACTION1:ACTION2:ACTION3...} 
    --============================================================================== 
    function decode_with_checksum ( 
        p_msg  in varchar2 , 
        p_region_id in number default null ) 
        return varchar2 
    is 
        l_msg               varchar2(32767); 
        l_expected_checksum varchar2(32767); 
        l_computed_checksum varchar2(32767); 
        i                   pls_integer := instr(p_msg,'/'); 
        l_salt              varchar2(255); 
        l_error_message     varchar2(4000); 
    begin 
        l_salt := get_salt(p_region_id); 
        if apex_application.g_debug then
            apex_debug.enter ( 
                c_g_package_prefix||'decode_with_checksum' , 
                'p_msg'                    , p_msg     , 
                'l_salt'                   , l_salt    , 
                'g_region_id'              , g_region_id );
        end if;
        if p_msg is null and l_salt is null then 
            null; 
        elsif i > 0 then 
            l_msg               := substr(p_msg, 1, i-1); 
            l_expected_checksum := substr(p_msg, i+1); 
            l_computed_checksum := wwv_flow_utilities.lov_checksum ( 
                                       p_string => case 
                                                   when l_salt is null then l_msg 
                                                   else l_msg||'/'||l_salt 
                                                   end ); 
            if (l_computed_checksum is null and l_expected_checksum is null) 
                or l_computed_checksum = l_expected_checksum 
            then 
                if length(l_msg) > 0 then 
                    l_msg := sys.utl_raw.cast_to_varchar2(sys.utl_encode.base64_decode(sys.utl_raw.cast_to_raw ( 
                                translate ( 
                                    l_msg, 
                                    c_decode_from_chars, 
                                    c_decode_to_chars )))); 
                end if; 
            else 
                apex_debug.warn('... expected "%s" does not match computed "%s"', l_expected_checksum, l_computed_checksum); 
                raise_application_error(-20001, c_g_package_prefix||'decode_with_checksum: checksum mismatch!'); 
                /* 
                apex_error.add_error ( 
                    p_message => c_g_package_prefix||'decode_with_checksum: checksum mismatch!' , 
                    p_display_location => apex_error.c_on_error_page ); 
                    */ 
            end if; 
        else 
            l_error_message := c_g_package_prefix||'decode_with_checksum: checksum message format error (expected text/checksum/)'; 
            apex_debug.warn(l_error_message); 
            raise_application_error(-20001, l_error_message); 
            /* 
            apex_error.add_error ( 
                p_message => c_g_package_prefix||'decode_with_checksum: '||l_error_message , 
                p_display_location => apex_error.c_on_error_page ); 
                */ 
        end if; 
        return l_msg; 
    end decode_with_checksum; 
    --============================================================================== 
    -- writes the menu options to the json output 
    --============================================================================== 
    procedure write_option_data ( 
        p_menu_option       t_menu_option, 
        p_affected_element  varchar2 ) 
    as 
        C_TRUE  constant varchar2(10) := 'TRUE'; 
        C_FALSE constant varchar2(10) := 'FALSE'; 
        l_href           varchar2(4000) := p_menu_option.href; 
        l_prepare_url    boolean        := nvl( upper( p_menu_option.prepare_url ), C_TRUE ) = C_TRUE; 
    begin 
        -- if there's no #ID# in the target and prepare_url is not explicitly false, prepare the url  
        if instr( l_href, c_g_pk_value_subst ) < 1 and l_prepare_url  then 
            l_href := apex_util.prepare_url ( 
                p_url                => apex_plugin_util.replace_substitutions ( l_href ),  
                p_triggering_element => apex_escape.js_literal( p_affected_element ) ); 
            -- if the prepare url is not true, set it to false in order to prevent unnecessary ajax requests 
            if nvl( upper( p_menu_option.prepare_url ), C_FALSE ) <> C_TRUE then 
                l_prepare_url := false; 
            end if;  
        elsif instr( l_href, c_g_pk_value_subst ) < 1 then 
            l_href := apex_plugin_util.replace_substitutions(l_href); 
        end if;  
        -- create the option object 
        apex_json.write( 'label',       apex_plugin_util.replace_substitutions( p_menu_option.label )        ); 
        apex_json.write( 'icon',        p_menu_option.icon                                                   ); 
        apex_json.write( 'action',      p_menu_option.action                                                 ); 
        apex_json.write( 'href',        l_href                                                               );   
        apex_json.write( 'prepareURL',  l_prepare_url                                                        );  
        apex_json.write( 'newTab',      upper(p_menu_option.new_tab) = C_TRUE                                );  
        apex_json.write( 'actionEvent', p_menu_option.action_event                                           ); 
        apex_json.write( 'buttonClass', apex_plugin_util.replace_substitutions( p_menu_option.button_class ) ); 
        apex_json.write( 'tooltip',     apex_plugin_util.replace_substitutions( p_menu_option.tooltip )      ); 
        if p_menu_option.action_function is not null then 
            apex_json.write_raw( 'actionFunction', 'function(){' || apex_plugin_util.replace_substitutions( p_menu_option.action_function ) || '}' ); 
        end if; 
    end write_option_data; 
    --============================================================================== 
    -- get the affected element 
    --============================================================================== 
    function get_affected_element 
        ( p_dynamic_action apex_plugin.t_dynamic_action ) 
        return varchar2 
    as 
        c_type   constant   p_dynamic_action.affected_elements_type%type := p_dynamic_action.affected_elements_type; 
        l_static_id         varchar2(200);     
        l_result            varchar2(200); 
    begin 
        if c_type = 'JQUERY_SELECTOR' then 
            l_result := p_dynamic_action.affected_elements; 
        else  
            begin 
                case c_type 
                    when  'REGION' then 
                        l_result := 'R' || p_dynamic_action.affected_region_id; 
                        select static_id 
                          into l_static_id 
                          from apex_application_page_regions 
                         where application_id   = apex_application.g_flow_id 
                           and page_id          = c_g_page_id 
                           and region_id        = p_dynamic_action.affected_region_id 
                           and static_id is not null; 
                    when 'BUTTON' then 
                        l_result := 'B' || p_dynamic_action.affected_button_id; 
                        select button_static_id 
                          into l_static_id 
                          from apex_application_page_buttons 
                         where application_id   = apex_application.g_flow_id 
                           and page_id          = c_g_page_id 
                           and button_id        = p_dynamic_action.affected_button_id 
                           and button_static_id is not null; 
                end case; 
                l_result := '#' || l_static_id; 
 
            exception 
                when no_data_found then 
                    l_result := '#' || l_result; 
            end; 
        end if; 
        return l_result; 
    end get_affected_element; 
    --============================================================================== 
    -- get the template data 
    --============================================================================== 
    procedure get_template_data ( 
        p_button_template_name in varchar2 default 'ICON' ) 
    as 
        c_is_current_yes     constant   varchar2(10)   := 'Yes'; 
        c_font_apex_library  constant   varchar2(1000) := 'FONTAPEX';    
        c_font_apex_prefix   constant   varchar2(10)   := 'fa'; 
        c_icon_text_type     constant   varchar2(100)  := 'TEXT_WITH_ICON'; 
        c_ut_icon            constant   varchar2(100)  := 'ICON'; 
        c_ut_left_icon       constant   varchar2(100)  := 'LEFTICON'; 
        c_ut_right_icon      constant   varchar2(100)  := 'RIGHTICON'; 
        c_rw_template        constant   varchar2(100)  := 'BUTTON'; 
        c_rw_icon            constant   varchar2(100)  := 'BUTTON_DISPLAY_ICON'; 
        l_rw_option_name                varchar2(100)  := 'BUTTON_DISPLAY_'; 
        l_rw_left_icon       constant   varchar2(100)  := 'ICON_TEXT';      
        l_rw_right_icon      constant   varchar2(100)  := 'TEXT_ICON';           
        l_ut_template                   varchar2(100)  := p_button_template_name; 
        l_ut_option_name                varchar2(100); 
 
        l_theme_number                  pls_integer; 
    begin 
        if instr( p_button_template_name, c_icon_text_type ) > 0 then 
            l_ut_template := c_icon_text_type; 
            if instr( p_button_template_name, 'LEFT' ) > 0 then 
                l_ut_option_name := c_ut_left_icon; 
                l_rw_option_name := l_rw_option_name || l_rw_left_icon; 
            else  
                l_ut_option_name := c_ut_right_icon; 
                l_rw_option_name := l_rw_option_name || l_rw_right_icon; 
            end if; 
        else  
            l_rw_option_name := l_rw_option_name || p_button_template_name; 
        end if; 
        apex_json.open_object( 'buttonTemplates' ); 
        for i in ( select t.icon_library, 
                          t.custom_icon_prefix_class, 
                          o.css_classes, 
                          b.template, 
                          b.internal_name as template_name, 
                          o.name          as option_name, 
                          t.theme_number 
                     from apex_application_themes      t 
                     join apex_application_temp_button b  
                       on ( b.application_id = t.application_id and b.internal_name in ( l_ut_template, c_rw_template, c_ut_icon) ) 
                     left join apex_appl_template_options  o 
                       on ( o.button_template_id = b.button_template_id and o.name in ( l_ut_option_name, l_rw_option_name, c_rw_icon ) ) 
                    where t.application_id = apex_application.g_flow_id 
                      and is_current       = c_is_current_yes ) 
        loop 
            l_theme_number := i.theme_number; 
            if i.template_name = c_ut_icon or i.option_name = 'BUTTON_DISPLAY_ICON' then 
                apex_json.open_object( 'icon' ); 
            else  
                apex_json.open_object( 'button' ); 
            end if; 
 
            apex_json.write( 'template' , i.template); 
            apex_json.write( 'btnClass' , i.css_classes); 
            if i.custom_icon_prefix_class is null and i.icon_library = c_font_apex_library then 
                apex_json.write( 'iconType' , c_font_apex_prefix); 
            else 
                apex_json.write( 'iconType' , i.icon_library); 
            end if; 
            apex_json.close_object; 
 
        end loop; 
        apex_json.write( 'theme' , l_theme_number ); 
        apex_json.close_object; 
    end get_template_data; 
 
    --============================================================================== 
    -- centralized call to get the list information 
    --============================================================================== 
    function get_list_info ( 
        p_list_name varchar2 ) 
        return t_list_row 
    is 
        -- list data 
        l_list_row                       t_list_row; 
        -- exceptions 
        e_list_not_found_num             pls_integer     := -20001; 
        e_list_not_found_msg             varchar2(1000)  := c_g_package_prefix||'.render: The provided list name '|| apex_escape.js_literal( p_list_name ) ||' cannot be found!'; 
    begin 
        -- get the list data 
        select list_id, 
               list_type_code, 
               list_query  
          into l_list_row.id, 
               l_list_row.list_type_code, 
               l_list_row.list_query 
          from apex_application_lists 
         where application_id = c_g_app_id 
           and list_name      = p_list_name; 
        -- 
        return l_list_row; 
    exception 
        when no_data_found then 
            -- list cannot be found, raise exception 
            raise_application_error( e_list_not_found_num, e_list_not_found_msg ); 
    end get_list_info; 
    --============================================================================== 
    -- standard render function 
    --============================================================================== 
    function render ( 
        p_dynamic_action in apex_plugin.t_dynamic_action, 
        p_plugin         in apex_plugin.t_plugin ) 
        return apex_plugin.t_dynamic_action_render_result 
    is 
        -- list entry column positions 
        subtype t_column_pos is pls_integer range 1..25; 
        c_column_pos_level      constant t_column_pos   := 1; 
        c_column_pos_label      constant t_column_pos   := 2; 
        c_column_pos_target     constant t_column_pos   := 3; 
        c_column_pos_icon       constant t_column_pos   := 5; 
        c_column_pos_a01        constant t_column_pos   := 8; 
        c_column_pos_a02        constant t_column_pos   := 9; 
        c_column_pos_a03        constant t_column_pos   := 10; 
        c_column_pos_a04        constant t_column_pos   := 11; 
        c_column_pos_a05        constant t_column_pos   := 12; 
        c_column_pos_a06        constant t_column_pos   := 13; 
        c_column_pos_a07        constant t_column_pos   := 14; 
        l_result                         apex_plugin.t_dynamic_action_render_result; 
        c_da_id                 constant p_dynamic_action.id%type                 := p_dynamic_action.id; 
        l_ajax_id                        varchar2(4000)                           := apex_plugin.get_ajax_identifier; 
        -- affected region id 
        l_region_id                      p_dynamic_action.affected_region_id%type := p_dynamic_action.affected_region_id; 
        l_affected_element      constant varchar2(200)                            := get_affected_element ( p_dynamic_action ); 
 
        -- application wide (/global) attributes 
        c_g_menu_icon           constant p_plugin.attribute_01%type               := p_plugin.attribute_01; 
        c_g_menu_title          constant p_plugin.attribute_02%type               := p_plugin.attribute_02; 
        --plug-in attributes 
        c_list_name             constant p_dynamic_action.attribute_01%type       := p_dynamic_action.attribute_01; 
        c_options               constant p_dynamic_action.attribute_03%type       := p_dynamic_action.attribute_03; 
        c_hide_disabled         constant boolean                                  := instr( c_options, 'HIDE_DISABLED'            ) > 0; 
        c_inline_buttons        constant boolean                                  := instr( c_options, 'INLINE_BUTTONS'           ) > 0; 
        c_delay_init            constant boolean                                  := instr( c_options, 'DELAY_INIT'               ) > 0; 
        c_hide_disabled_menu    constant boolean                                  := instr( c_options, 'DONT_RENDER_DISABLED_MENU') > 0; 
        c_button_template       constant p_dynamic_action.attribute_04%type       := p_dynamic_action.attribute_04; 
        c_num_of_buttons        constant p_dynamic_action.attribute_05%type       := p_dynamic_action.attribute_05; 
        c_enabled_buttons_first constant boolean                                  := nvl( p_dynamic_action.attribute_06, 'Y' ) = 'Y'; 
        c_button_names          constant p_dynamic_action.attribute_07%type       := p_dynamic_action.attribute_07; 
        c_menu_filter           constant p_dynamic_action.attribute_08%type       := p_dynamic_action.attribute_08; 
        c_button_css_cls        constant p_dynamic_action.attribute_09%type       := p_dynamic_action.attribute_09; 
        c_override_defaults     constant boolean                                  := nvl( p_dynamic_action.attribute_10, 'Y' ) = 'Y'; 
        c_target_selector       constant p_dynamic_action.attribute_11%type       := p_dynamic_action.attribute_11; 
        c_menu_icon             constant p_dynamic_action.attribute_12%type       := p_dynamic_action.attribute_12; 
        c_menu_title            constant p_dynamic_action.attribute_13%type       := p_dynamic_action.attribute_13; 
        c_delay                 constant p_dynamic_action.attribute_14%type       := nvl(p_dynamic_action.attribute_14, '500'); 
 
        -- list data 
        l_list_row                       t_list_row; 
        -- region type 
        l_region_type                    apex_application_page_regions.source_type_plugin_name%type; 
        -- list entry data 
        l_is_used                        boolean; 
        l_menu_option                    t_menu_option; 
        -- dynamic list entries 
        l_context                        apex_exec.t_context; 
        l_num_of_cols                    pls_integer; 
        -- nested list helpers 
        l_counter                        pls_integer                               := 0; 
        l_depth                          pls_integer                               := 0; 
        l_prev_level                     pls_integer                               := 0; 
        l_parent_disabled                boolean                                   := false; 
    begin 
 
        --debug 
        if apex_application.g_debug then 
            apex_plugin_util.debug_dynamic_action ( 
                p_plugin         => p_plugin, 
                p_dynamic_action => p_dynamic_action ); 
        end if; 
        -- create a json object  
        apex_json.initialize_clob_output( p_preserve => true ); 
        -- { 
        apex_json.open_object; 
        -- plug-in attributes 
        apex_json.write( 'daId',                c_da_id                                  ); 
        apex_json.write( 'ajaxId',              l_ajax_id                                ); 
        apex_json.write( 'menuIcon',            coalesce( c_menu_icon,  c_g_menu_icon  ) ); 
        apex_json.write( 'menuLabel',           coalesce( c_menu_title, c_g_menu_title ) ); 
        apex_json.write( 'inlineButtons',       c_inline_buttons                         ); 
        apex_json.write( 'inlineButtonNames',   c_button_names                           ); 
        apex_json.write( 'maxNumOfButtons',     c_num_of_buttons                         ); 
        apex_json.write( 'enabledButtonsFirst', c_enabled_buttons_first                  ); 
        apex_json.write( 'buttonCSS',           c_button_css_cls                         ); 
        apex_json.write( 'hideDisabled',        c_hide_disabled                          ); 
        apex_json.write( 'targetSelector',      c_target_selector                        ); 
        apex_json.write( 'menuFilters',         c_menu_filter                            ); 
        apex_json.write( 'hideDisabledMenu',    c_hide_disabled_menu                     ); 
        -- 
        l_list_row := get_list_info( p_list_name => c_list_name ); 
        -- the items array contains the menu options objects (and the individual settings) 
        -- items: [ 
        apex_json.open_array( 'items' ); 
        -- we have to handle static and dynamic lists in a differently 
        -- static lists 
        if l_list_row.list_type_code = c_g_list_type_static then 
 
            -- loop through all the list entries ( the apex_application_list_entries contains the name of the build option, but  
            -- for the is_component_used we need the id; that's why the join ) 
            <<select_list_metadata_loop>> 
            for i in ( select level, 
                              v.list_entry_id, 
                              v.list_entry_parent_id, 
                              v.entry_text, 
                              v.entry_image, 
                              v.build_option, 
                              v.authorization_scheme_id, 
                              v.condition_type_code, 
                              v.condition_expression1, 
                              v.condition_expression2, 
                              v.entry_attribute_01 as action,            -- action(/option) name, will be referenced from the report query,  
                              v.entry_attribute_02 as action_event,      -- custom action to trigger,  
                              v.entry_attribute_03 as action_function,   -- js code to execute,  
                              v.entry_attribute_04 as prepare_url,       -- True/False - indicates whether the url needs to be prepared on the server or not ((!) default: TRUE),  
                              v.entry_attribute_05 as new_tab,           -- True/False - indicates whether open the url in a new tab or not  
                              v.entry_attribute_06 as button_class,      -- class to be applied if entry is inline button 
                              v.entry_attribute_07 as tooltip,           -- tooltip 
                              v.entry_target,                            -- url/page to open 
                              v.display_sequence, 
                              v.build_option_id 
                         from ( select le.list_entry_id, 
                                       le.list_entry_parent_id, 
                                       le.entry_text, 
                                       le.entry_image, 
                                       le.build_option, 
                                       le.authorization_scheme_id, 
                                       le.condition_type_code, 
                                       le.condition_expression1, 
                                       le.condition_expression2,      
                                       le.entry_attribute_01, 
                                       le.entry_attribute_02, 
                                       le.entry_attribute_03, 
                                       le.entry_attribute_04, 
                                       le.entry_attribute_05, 
                                       le.entry_attribute_06, 
                                       le.entry_attribute_07, 
                                       le.entry_target,      
                                       le.display_sequence,                            
                                       bo.build_option_id 
                                  from apex_application_list_entries  le 
                                  left join apex_application_build_options bo 
                                    on ( le.application_id = bo.application_id and le.build_option = bo.build_option_name ) 
                                 where le.list_id = l_list_row.id 
                         ) v 
                        connect by prior v.list_entry_id = v.list_entry_parent_id 
                        start with v.list_entry_parent_id is null 
                     order siblings by v.display_sequence 
            ) loop 
                -- counter as index 
                l_counter := l_counter + 1; 
                -- if as sub-list-entry's parent is disabled(ie. not used) skip the entry 
                if i.level > l_prev_level and l_parent_disabled then 
                    continue select_list_metadata_loop; 
                end if; 
                -- check if the list entry is "used", ie. execute server-side condition, check build-options 
                l_is_used := apex_plugin_util.is_component_used ( 
                                p_build_option_id         => i.build_option_id, 
                                p_authorization_scheme_id => i.authorization_scheme_id, 
                                p_condition_type          => i.condition_type_code, 
                                p_condition_expression1   => i.condition_expression1, 
                                p_condition_expression2   => i.condition_expression2 ); 
 
                -- store the current level 
                l_prev_level := i.level; 
                -- flag for the parent's state 
                l_parent_disabled := false; 
                -- skip the not used components 
                if not l_is_used then 
                    -- flag for the parent's state 
                    l_parent_disabled := true; 
                    continue select_list_metadata_loop; 
                end if; 
 
                -- get back to the curret level, close arrays & objects 
                if l_counter > 1 and l_depth >= i.level then 
                    for x in i.level .. l_depth loop 
                        apex_json.close_array; 
                        apex_json.close_object; 
                    end loop; 
                end if;  
                -- open option object 
                -- { 
                apex_json.open_object; 
                l_menu_option.label             := i.entry_text; 
                l_menu_option.href              := i.entry_target; 
                l_menu_option.icon              := i.entry_image; 
                l_menu_option.action            := i.action; 
                l_menu_option.action_event      := i.action_event;        
                l_menu_option.action_function   := i.action_function; 
                l_menu_option.prepare_url       := i.prepare_url; 
                l_menu_option.new_tab           := i.new_tab; 
                l_menu_option.button_class      := i.button_class; 
                l_menu_option.tooltip           := i.tooltip; 
                write_option_data (  
                    p_menu_option      => l_menu_option, 
                    p_affected_element => l_affected_element ); 
                -- we always open the items array 
                -- items: [ 
                apex_json.open_array( 'items' ); 
                -- store the current depth 
                l_depth := i.level; 
            end loop select_list_metadata_loop; 
        -- dynamic lists (sql, pl/sql function returning sql query) 
        elsif l_list_row.list_type_code in ( c_g_list_type_sql, c_g_list_type_plsql ) then 
            -- 
            apex_debug.trace('... List Name=%s, SQL Query=%s', c_list_name, l_list_row.list_query); 
            -- open the query context 
            l_context := apex_exec.open_query_context ( 
                             p_location             => apex_exec.c_location_local_db, 
                             p_sql_query            => l_list_row.list_query, 
                             p_plsql_function_body  => l_list_row.list_query ); 
            -- get the number of columns 
            l_num_of_cols := apex_exec.get_column_count ( p_context => l_context ); 
            while apex_exec.next_row ( l_context )  loop 
                -- counter as index 
                l_counter := l_counter + 1; 
                -- store the current level 
                l_menu_option.level := apex_exec.get_number( l_context, c_column_pos_level ); 
 
                -- get back to the curret level, close arrays & objects 
                if l_counter > 1 and l_depth >= l_menu_option.level then 
                    for x in l_menu_option.level .. l_depth loop 
                        apex_json.close_array; 
                        apex_json.close_object; 
                    end loop; 
                end if;  
                -- { 
                apex_json.open_object; 
                -- we do not have to get the positions of the columns, list queries must have a specific column order  
                -- create the option object 
                l_menu_option.label             := apex_exec.get_varchar2( l_context, c_column_pos_label  ); 
                l_menu_option.href              := apex_exec.get_varchar2( l_context, c_column_pos_target ); 
                l_menu_option.icon              := apex_exec.get_varchar2( l_context, c_column_pos_icon   ); 
                l_menu_option.action            := apex_exec.get_varchar2( l_context, c_column_pos_a01    ); 
                -- optional columns 
                l_menu_option.action_event      := case when l_num_of_cols >= 9  then apex_exec.get_varchar2( l_context, c_column_pos_a02 ) end; 
                l_menu_option.action_function   := case when l_num_of_cols >= 10 then apex_exec.get_varchar2( l_context, c_column_pos_a03 ) end; 
                l_menu_option.prepare_url       := case when l_num_of_cols >= 11 then apex_exec.get_varchar2( l_context, c_column_pos_a04 ) end; 
                l_menu_option.new_tab           := case when l_num_of_cols >= 12 then apex_exec.get_varchar2( l_context, c_column_pos_a05 ) end; 
                l_menu_option.button_class      := case when l_num_of_cols >= 13 then apex_exec.get_varchar2( l_context, c_column_pos_a06 ) end; 
                l_menu_option.tooltip           := case when l_num_of_cols >= 14 then apex_exec.get_varchar2( l_context, c_column_pos_a07 ) end; 
                write_option_data (  
                    p_menu_option      => l_menu_option, 
                    p_affected_element => l_affected_element ); 
                -- we always open the items array 
                -- items: [ 
                apex_json.open_array( 'items' ); 
                -- store the current depth 
                l_depth := l_menu_option.level; 
            end loop; 
            -- close context 
            apex_exec.close( l_context ); 
        end if; 
        -- get back to the first level 
        for i in 1 .. l_depth loop 
            apex_json.close_array; 
            apex_json.close_object; 
        end loop; 
        -- ] items 
        apex_json.close_array; 
        -- write the button template data 
        get_template_data( p_button_template_name => c_button_template); 
        -- } 
        apex_json.close_object; 
 
        if c_delay_init then 
            l_result.javascript_function := 'function(){ let da = this; setTimeout( function(){ apex.redwood.actionMenu.init( da, ' ||  apex_json.get_clob_output( p_free => true ) || ');}, '|| c_delay ||'); }'; 
        else  
            -- a small delay is needed to cater for a change to classic report (list item template) now listening to "apexreadyend"
            l_result.javascript_function := 'function(){ let da = this; setTimeout( function(){apex.redwood.actionMenu.init( da, ' ||  apex_json.get_clob_output( p_free => true ) || ');},1); }'; 
            --l_result.javascript_function := 'function(){ apex.redwood.actionMenu.init( this, ' ||  apex_json.get_clob_output( p_free => true ) || '); }'; 
        end if; 
        return l_result; 
    -- handle exceptions 
    exception 
        when others then 
            apex_exec.close( l_context ); 
            apex_json.free_output; 
            apex_debug.message( dbms_utility.format_error_backtrace ); 
            l_result.javascript_function := 'function(){ apex.debug.error( "Dynamic Action ID:' || p_dynamic_action.id || ' Error: '|| SQLERRM || '", this );}'; 
            return l_result; 
    end render; 
    --============================================================================== 
    -- standard ajax function 
    --============================================================================== 
    function ajax ( 
        p_dynamic_action in apex_plugin.t_dynamic_action, 
        p_plugin         in apex_plugin.t_plugin ) 
        return apex_plugin.t_dynamic_action_ajax_result 
    is 
        l_result                     apex_plugin.t_dynamic_action_ajax_result; 
        l_region_id                  p_dynamic_action.affected_region_id%type    := p_dynamic_action.affected_region_id; 
        l_button_id                  p_dynamic_action.affected_button_id%type    := p_dynamic_action.affected_button_id; 
 
        c_list_name                  p_dynamic_action.attribute_01%type          := p_dynamic_action.attribute_01;             
        c_data_menu_id               p_dynamic_action.attribute_01%type          := p_dynamic_action.attribute_15;             
        c_skip_checksum_requirement  constant boolean                            := nvl( p_dynamic_action.attribute_02, 'N') = 'Y'; 
 
        -- list data 
        l_list_row                   t_list_row; 
        -- dynamic list entries 
        l_context                    apex_exec.t_context; 
        l_num_of_cols                pls_integer; 
        -- list entry column positions 
        subtype t_column_pos is pls_integer range 1..25; 
        c_column_pos_target          constant t_column_pos   := 3; 
        c_column_pos_a01             constant t_column_pos   := 8; 
         
        l_pk_value                   varchar2(4000)                     := apex_application.g_x01; 
        l_menu_entry_id              varchar2(4000)                     := apex_application.g_x02; 
        l_checksum                   varchar2(4000)                     := apex_application.g_x03; 
 
        l_menu_entry_target          apex_application_list_entries.entry_target%type; 
        l_menu_entry_attribute_01    apex_application_list_entries.entry_attribute_01%type; 
        l_url                        varchar2(4000); 
        l_decoded_values             apex_t_varchar2; 
        l_allowed_actions            apex_t_varchar2; 
        l_static_id_check            boolean := false; 
 
        l_region_source_type         apex_application_page_regions.source_type_plugin_name%type; 
        l_secure_region_types        apex_t_varchar2                    := apex_string.split('NATIVE_SQL_REPORT:NATIVE_IR:NATIVE_IG:NATIVE_JQM_LIST_VIEW:NATIVE_CARDS',':'); 
    begin 
        --debug 
        if apex_application.g_debug then 
            apex_plugin_util.debug_dynamic_action ( 
                p_plugin         => p_plugin, 
                p_dynamic_action => p_dynamic_action ); 
            apex_debug.enter ( 
                c_g_package_prefix||'ajax'   , 
                'l_pk_value'               , l_pk_value      , 
                'l_menu_entry_id'          , l_menu_entry_id , 
                'l_checksum'               , l_checksum      , 
                'l_region_id'              , l_region_id     ); 
        end if; 
        -- 
        l_list_row := get_list_info( p_list_name => c_list_name ); 
 
        if l_list_row.list_type_code = c_g_list_type_static then 
            -- get the region type 
            -- get the menu target
            begin
                select entry_target, 
                       entry_attribute_01 
                  into l_menu_entry_target, 
                       l_menu_entry_attribute_01 
                  from apex_application_list_entries 
                 where application_id     = apex_application.g_flow_id 
                   and list_name          = c_list_name 
                   and entry_attribute_01 = l_menu_entry_id; 
            exception
                when too_many_rows then
                    raise_application_error(-20001, 'your list "' || c_list_name || '" has list entries with a non-unique A01 setting with the following value: ' || l_menu_entry_id || '!');
                when no_data_found then
                    if l_menu_entry_id is null then
                        raise_application_error(-20001, 'your list item A01 value is null. You must provide a unique value for the list item to be indentified!');
                    else
                        raise_application_error(-20001, 'could not locate the list item entry id: ' || l_menu_entry_id || ' for within the list: ' || c_list_name || '!');
                    end if;
                when others then
                    raise;
            end; 
        elsif l_list_row.list_type_code in ( c_g_list_type_sql, c_g_list_type_plsql ) then 
            -- 
            apex_debug.trace('... List Name=%s, SQL Query=%s', c_list_name, l_list_row.list_query); 
            -- open the query context 
            l_context := apex_exec.open_query_context ( 
                             p_location             => apex_exec.c_location_local_db, 
                             p_sql_query            => l_list_row.list_query, 
                             p_plsql_function_body  => l_list_row.list_query ); 
            while apex_exec.next_row ( l_context )  loop 
                l_menu_entry_attribute_01  := apex_exec.get_varchar2( l_context, c_column_pos_a01    ); 
                if l_menu_entry_attribute_01 = l_menu_entry_id then 
                    l_menu_entry_target    := apex_exec.get_varchar2( l_context, c_column_pos_target ); 
                    exit; 
                end if; 
            end loop; 
            -- close context 
            apex_exec.close( l_context ); 
            if l_menu_entry_target is null then 
                raise_application_error(-20001, 'cannot locate the list item URL to prepare from the dynamic list query results! There is no matching A01 setting for the provided value: '|| l_menu_entry_id); 
            end if; 
        end if; 
 
        if not c_skip_checksum_requirement and l_region_id is not null then 

            -- check the region type, as multi-row regions generate checksums 
            select source_type_plugin_name 
              into l_region_source_type 
              from apex_application_page_regions 
             where application_id = apex_application.g_flow_id 
               and page_id        = c_g_page_id 
               and region_id      = l_region_id; 
 
            if l_region_source_type member of l_secure_region_types then 
 
              if l_checksum is null then 
                  raise_application_error(-20001, 'the required security checksum is missing or NULL. This is a misconfiguration issue by the developer, please refer to the documentation!'); 
              end if;

              -- decode our protected value 
              l_decoded_values := apex_string.split( 
                                      decode_with_checksum(  
                                            p_msg       => l_checksum,  
                                            p_region_id => l_region_id ) 
                                      , '|'); 
 
              if l_decoded_values.count = 1 then 
                  raise_application_error(-20001, 'no actions have been added to the checksum! This is a misconfiguration issue by the developer, please refer to the documentation! Syntax is {ID}|{ACTIONS}'); 
              elsif l_decoded_values.count = 0 then 
                  raise_application_error(-20001, 'the decoded checksum is null! Please check the data used in the generation of the checksum in your SQL query!'); 
              else 
                  l_allowed_actions := apex_string.split(l_decoded_values(2),':'); 
                  if l_allowed_actions.count = 0 then 
                      raise_application_error(-20001, 'no actions have been allowed for the ID value: ' || l_decoded_values(1)); 
                  end if; 
                  if l_menu_entry_attribute_01 not member of l_allowed_actions and 'ALL' not member of l_allowed_actions then 
                      raise_application_error(-20001, 'the action "' || l_menu_entry_attribute_01 || '" is not allowed: ' || l_decoded_values(2)); 
                  end if; 
                  l_pk_value := l_decoded_values(1); 
              end if; 
            else 
                l_static_id_check := true; 
            end if; 
        end if; 
 
        if l_button_id is not null or l_static_id_check then 
          if c_data_menu_id is null then 
              raise_application_error(-20001, 'the plugin attribute value "Secure ID" is NULL! It must match your nvl("data-menu-id", "id") attribute value from your HTML tag e.g. ' || apex_escape.html('<apex-action-button>')); 
          elsif c_data_menu_id != l_pk_value then 
              raise_application_error(-20001, 'the button HTML attribute nvl("data-menu-id", "id")="' || l_pk_value || '" does not match the "Secure ID" plugin attribute value of "' || c_data_menu_id || '"'); 
          end if; 
        end if; 
        -- replace the id value 
        l_menu_entry_target := replace ( l_menu_entry_target, c_g_pk_value_subst, l_pk_value ); 
        -- prepare url 
        l_url := apex_util.prepare_url (  
            p_url                => apex_plugin_util.replace_substitutions ( l_menu_entry_target ), 
            p_triggering_element => apex_escape.js_literal ( get_affected_element ( p_dynamic_action ) )); 
        apex_json.open_object; 
        apex_json.write( 'success', true  ); 
        apex_json.write( 'url',     l_url ); 
        apex_json.close_object; 
        return l_result; 
    exception 
        when others then 
            apex_debug.message( dbms_utility.format_error_backtrace ); 
            apex_json.open_object; 
            apex_json.write( 'success', false   ); 
            apex_json.write( 'message', SQLERRM ); 
            apex_json.close_object; 
        return l_result; 
 
    end ajax; 
end apex_actions_menu_plugin;
/