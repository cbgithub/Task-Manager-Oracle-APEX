create or replace package "REDWOOD_DATA_SWITCHER_PLUGIN" as
--------------------------------------------------------------------------------
--
--  Copyright (c) 2024, Oracle and/or its affiliates.
--
--    NAME
--      redwood_data_switcher_plugin.sql
--
--    DESCRIPTION
--      Redwood Data Switcher Page Item Plugin for Oracle APEX
--
--    SECURITY
--      No grants
--
--    MODIFIED (MM/DD/YYYY)
--     mnolan   12/08/2024 - Created
--
--------------------------------------------------------------------------------

procedure render (
    p_plugin in             apex_plugin.t_plugin,
    p_item   in             apex_plugin.t_item,
    p_param  in             apex_plugin.t_item_render_param,
    p_result in out nocopy  apex_plugin.t_item_render_result );

procedure ajax (
    p_plugin in             apex_plugin.t_plugin,
    p_item   in             apex_plugin.t_item,
    p_param  in             apex_plugin.t_item_ajax_param,
    p_result in out nocopy  apex_plugin.t_item_ajax_result );


end "REDWOOD_DATA_SWITCHER_PLUGIN";
/
create or replace package body "REDWOOD_DATA_SWITCHER_PLUGIN" as
--------------------------------------------------------------------------------
--
--  Copyright (c) 2024, Oracle and/or its affiliates.
--
--    NAME
--      redwood_data_switcher_plugin.pkb
--
--    DESCRIPTION
--      Redwood Data Switcher Page Item Plugin for Oracle APEX
--
--    SECURITY
--      No grants
--
--    MODIFIED (MM/DD/YYYY)
--     mnolan   08/12/2024 - Created
--
--------------------------------------------------------------------------------

c_show_search_after_default    constant number        := 5;
c_lov_items_max_values_in_list constant number        := 250;
c_html                         constant varchar2(4)   := 'HTML';
c_json                         constant varchar2(4)   := 'JSON';
c_contains                     constant varchar2(255) := 'contains';
c_suggestion_column            constant varchar2(255) := 'SUGGESTION';
g_first_value                  varchar2(32767);

--==============================================================================
-- Raise an error with the plugin
--==============================================================================
procedure raise_error (
    p_message        in varchar2,
    p_page_item_name in varchar2 )
is
begin
    raise_application_error(-20001, p_page_item_name||': '||p_message);
end raise_error;
--==============================================================================
-- Emit the JSON error response
--==============================================================================
procedure handle_ajax_error (
    p_component_name in varchar2 default null,
    p_message        in varchar2,
    p_rollback       in boolean  default true )
is
begin

    if p_rollback then
        apex_debug.info('Performing rollback');
        rollback;
    end if;

    apex_plugin_util.print_json_http_header;
    apex_json.initialize_output (
        p_http_cache => false );

    apex_json.open_object;
    apex_json.write('success', false);
    apex_json.write('error', p_component_name|| ': ' ||p_message);
    apex_json.close_object;

end handle_ajax_error;

--==============================================================================
-- Emit an empty JSON success response
--==============================================================================
procedure emit_empty_response
is
begin

    apex_plugin_util.print_json_http_header;
    apex_json.initialize_output (
        p_http_cache => false );

    apex_json.open_object;
    apex_json.write('success', true);
    apex_json.open_array('data');
    apex_json.close_all;

end emit_empty_response;

--==============================================================================
-- Emit the combobox and select one/many data as HTML or JSON
--==============================================================================
function get_column_references (
    p_item               in            apex_plugin.t_item,
    p_template_cols_only in boolean default false )
    return apex_t_varchar2
is
    c_image_src_column       constant varchar2(32767) := trim(p_item.attribute_17);
    c_icon_column            constant varchar2(32767) := trim(p_item.attribute_10);
    c_initials_column        constant varchar2(32767) := trim(p_item.attribute_11);
    c_overline_column        constant varchar2(32767) := trim(p_item.attribute_18);
    c_primary_txt_column     constant varchar2(32767) := trim(p_item.attribute_19);
    c_secondary_txt_column   constant varchar2(32767) := trim(p_item.attribute_20);
    c_tertiary_txt_column    constant varchar2(32767) := trim(p_item.attribute_21);
    c_meta_column            constant varchar2(32767) := trim(p_item.attribute_22);

    l_allowed_columns        apex_t_varchar2          := apex_t_varchar2();

    procedure add_col ( p_column in varchar2 )
    is
    begin
        if p_column is not null then
            apex_string.push (
                p_table => l_allowed_columns,
                p_value => p_column );
        end if;
    end add_col;

begin

    -- template columns
    add_col(c_image_src_column);
    add_col(c_icon_column);
    add_col(c_initials_column);
    add_col(c_overline_column);
    add_col(c_primary_txt_column);
    add_col(c_secondary_txt_column);
    add_col(c_tertiary_txt_column);
    add_col(c_meta_column);

    if not p_template_cols_only then
        -- built-in columns
        add_col(p_item.lov_icon_column);
        add_col(p_item.lov_display_column);
        add_col(p_item.lov_return_column);
        -- extra cols
        add_col(c_suggestion_column);
    end if;

    return l_allowed_columns;

end get_column_references;
--==============================================================================
-- Emit the combobox and select one/many data as HTML or JSON
--==============================================================================
procedure emit_initial_value (
    p_context       in out nocopy apex_exec.t_context,
    p_item          in            apex_plugin.t_item,
    p_value         in            varchar2 default null,
    p_json          in out nocopy varchar2,
    p_display_value in out        varchar2 )
is
    l_display_value          varchar2(32767);
    l_return_value           varchar2(32767);
    l_name                   varchar2(32767);
    l_value                  varchar2(32767);
    c_display_extra_values   constant boolean         := p_item.lov_display_extra;
    c_placeholder            constant varchar2(4000)  := p_item.placeholder;
begin
    if apex_application.g_debug then
        apex_debug.enter( 'emit_initial_value');
    end if;

    apex_json.initialize_clob_output;

    apex_json.open_object();
    apex_json.open_array('data');
    apex_json.open_object();

    -- emit options
    <<data_rows>>
    while apex_exec.next_row(p_context) loop

        -- Otherwise, process multi-column result columns, skipping unsupported data types.
        <<data_columns>>
        for i in 1 .. apex_exec.get_column_count(p_context) loop
            continue when apex_exec.get_column(p_context,i).data_type in (
                apex_exec.c_data_type_blob,
                apex_exec.c_data_type_bfile,
                apex_exec.c_data_type_user_defined,
                apex_exec.c_data_type_sdo_geometry );

            l_name  := apex_exec.get_column(p_context,i).name;
            l_value := apex_exec.get_varchar2(p_context, i);

            -- handle LOV column mappings
            case l_name
                when p_item.lov_display_column then
                    l_display_value := l_value;

                when p_item.lov_return_column then
                    l_return_value := l_value;
                else
                    null;
            end case;

        end loop data_columns;

        -- if we found our matching value we should exit
        if l_return_value = p_value then
            exit;
        end if;

    end loop data_rows;

    -- this either has the matching value or the last row values which we use
    -- when we filter for the first row only
    apex_json.write('d', l_display_value, true);
    apex_json.write('r', l_return_value, true);

    -- Close data array and response object.
    apex_json.close_all;

    p_json := apex_json.get_clob_output;
    apex_json.free_output;

    -- We want to make sure our value is set in session state since it's the context for
    -- other regions and items e.g. child cascading LOV's
    apex_util.set_session_state(p_item.name, coalesce(l_return_value, case when c_display_extra_values then p_value else '' end));

    p_display_value :=
        case
            when c_display_extra_values then
                coalesce(l_display_value, l_return_value, p_value, c_placeholder)
            else coalesce(l_display_value, c_placeholder)
        end;

end emit_initial_value;
--==============================================================================
-- Emit the combobox and select one/many data as HTML or JSON
--==============================================================================
procedure emit_data_lov_items (
    p_context       in out nocopy apex_exec.t_context,
    p_item          in            apex_plugin.t_item,
    p_data_type     in            varchar2,
    p_value         in            varchar2 default null )
is
    -- LOV attributes
    c_has_additional_columns constant boolean := p_item.lov_columns.count > 0;
    c_has_display_column     constant boolean := p_item.lov_display_column is not null;
    c_has_icon_column        constant boolean := p_item.lov_icon_column is not null;
    c_display_extra_values   constant boolean := p_item.lov_display_extra;
    --
    l_name                   varchar2(32767);
    l_value                  varchar2(32767);
    l_display_value          varchar2(32767);
    l_return_value           varchar2(32767);
    l_icon_value             varchar2(32767);
    l_additional_data        apex_t_varchar2 := apex_t_varchar2();
    l_allowed_columns        apex_t_varchar2;
    l_row_index              pls_integer     := 0;
    l_field_index            pls_integer     := 0;
begin
    if apex_application.g_debug then
        apex_debug.enter( 'emit_data_lov_items',
                          'p_data_type'        , p_data_type);
    end if;

    l_allowed_columns := get_column_references( p_item => p_item );
    -- open JSON response object
    if p_data_type = c_json then
        apex_json.open_object();
        apex_json.write (
            p_name  => 'success',
            p_value => true );
    end if;

    -- emit columns meta data
    if c_has_additional_columns then
        case p_data_type
            when c_html then
                for i in 1 .. p_item.lov_columns.count loop
                    if p_item.lov_columns(i).column_name member of l_allowed_columns then
                        sys.htp.p (
                            '<a-column-metadata' ||
                            ' name="' || apex_escape.html_attribute(p_item.lov_columns(i).column_name) || '"' ||
                            ' searchable="' || case when p_item.lov_columns(i).is_searchable then 'true' else 'false' end || '"' ||
                            ' visible="' || case when p_item.lov_columns(i).is_visible then 'true' else 'false' end || '"' ||
                            ' index="' || l_field_index || '">' ||
                            '</a-column-metadata>' );
                        l_field_index := l_field_index + 1;
                    end if;
                end loop;
            when c_json then
                --apex_json.open_object('fields');
                apex_json.open_array('fields');
                for i in 1 .. p_item.lov_columns.count loop
                    if p_item.lov_columns(i).column_name member of l_allowed_columns then
                        apex_json.open_object();
                        apex_json.write (
                            p_name  => 'name',
                            p_value => p_item.lov_columns(i).column_name
                        );
                        apex_json.write (
                            p_name  => 'index',
                            p_value => l_field_index );
                        if not p_item.lov_columns(i).is_searchable then
                            apex_json.write (
                                p_name  => 'searchable',
                                p_value => false );
                        end if;
                        if not p_item.lov_columns(i).is_visible then
                            apex_json.write (
                                p_name  => 'visible',
                                p_value => false );
                        end if;
                        apex_json.close_object();
                        l_field_index := l_field_index + 1;
                    end if;
                end loop;
                apex_json.close_array();
        end case;
    end if;

    -- open JSON options array
    if p_data_type = c_json then
        apex_json.open_array('data');
    end if;

    -- emit options
    <<data_rows>>
    while apex_exec.next_row(p_context) loop

        l_row_index := l_row_index + 1;

        -- reset row meta data
        l_additional_data.delete;

        -- prepare row data
        if apex_exec.get_column_count(p_context) = 1 and p_item.lov_is_legacy then
            -- Single column legacy LOVs just have a return value.
            l_return_value := apex_exec.get_varchar2(p_context, 1);
        else
            -- Otherwise, process multi-column result columns, skipping unsupported data types.
            <<data_columns>>
            for i in 1 .. apex_exec.get_column_count(p_context) loop
                continue when apex_exec.get_column(p_context,i).data_type in (
                    apex_exec.c_data_type_blob,
                    apex_exec.c_data_type_bfile,
                    apex_exec.c_data_type_user_defined,
                    apex_exec.c_data_type_sdo_geometry );

                l_name  := apex_exec.get_column(p_context,i).name;
                l_value := apex_exec.get_varchar2(p_context, i);

                -- handle LOV column mappings
                case l_name

                    when p_item.lov_icon_column then
                        l_icon_value := l_value;

                    when p_item.lov_display_column then
                        l_display_value := l_value;

                    when p_item.lov_return_column then
                        l_return_value := l_value;

                    else
                        null;
                end case;

                -- handle additional columns
                if c_has_additional_columns and l_name member of l_allowed_columns then
                    apex_string.push ( p_table => l_additional_data,
                                       p_value => l_value );
                end if;

            end loop data_columns;
        end if;

        -- emit option
        case p_data_type
            when c_html then
                sys.htp.prn (
                    '<a-option' ||
                    case when c_has_display_column then
                        ' value="' || apex_escape.html_attribute(l_return_value) || '"'
                    end ||
                    case when c_has_icon_column then
                        ' icon="' || apex_escape.html_attribute(l_icon_value) || '"'
                    end ||
                    '>' ||
                    case when c_has_display_column
                        then apex_escape.html(l_display_value)
                        else apex_escape.html(l_return_value)
                    end );
                for i in 1 .. l_additional_data.count loop
                    sys.htp.prn (
                        '<a-option-column-value>' ||
                        apex_escape.html( l_additional_data(i) ) ||
                        '</a-option-column-value>' );
                end loop;
                sys.htp.p( '</a-option>' );
            when c_json then
                apex_json.open_object;
                apex_json.write (
                    p_name  => 'r',
                    p_value => l_return_value );
                if c_has_display_column then
                    apex_json.write (
                        p_name  => 'd',
                        p_value => l_display_value );
                end if;
                if c_has_icon_column then
                    apex_json.write (
                        p_name  => 'i',
                        p_value => l_icon_value );
                end if;
                if c_has_additional_columns then
                    apex_json.open_array('cols');
                    for i in 1 .. l_additional_data.count loop
                        apex_json.write ( p_value => l_additional_data(i) );
                    end loop;
                    apex_json.close_array();
                end if;
                apex_json.close_object();
        end case;

        -- we want to grab the first row value for settings session state for cascading LOV's
        if l_row_index = 1 then
            g_first_value := l_return_value;
        end if;

    end loop data_rows;

    -- we need to check if we need to output extra values
    if c_display_extra_values and p_value is not null and p_data_type = c_json and apex_exec.get_total_row_count(p_context) = 0 then
        apex_json.open_object;
        apex_json.write (
            p_name  => 'r',
            p_value => p_value );
        apex_json.write (
            p_name  => 'd',
            p_value => p_value );
        apex_json.close_object();
    end if;

    apex_debug.info('%s - number of rows emitted: %s', apex_exec.get_total_row_count(p_context));

    -- close JSON arrays and objects
    if p_data_type = c_json then
        -- Close data array and response object.
        apex_json.close_all;
    end if;

end emit_data_lov_items;
--==============================================================================
-- Public API, see specification
--==============================================================================
procedure open_query_context (
    p_context               in out nocopy apex_exec.t_context,
    p_first_row             in number                              default null,
    p_max_rows              in number                              default null,
    --
    p_item                  in apex_plugin.t_item,
    p_supports_icons        in boolean                             default false,
    p_supports_add_columns  in boolean                             default false,
    --
    p_search_text           in varchar2                            default null,
    p_search_operator       in apex_exec.t_search_operator default apex_exec.c_search_contains_like,
    p_search_case_sensitive in boolean                             default false,
    --
    p_filters               in apex_exec.t_filters         default apex_exec.c_empty_filters,
    p_sql_parameters        in apex_exec.t_parameters      default apex_exec.c_empty_parameters,
    p_order_bys             in apex_exec.t_order_bys       default apex_exec.c_empty_order_bys,
    --
    p_do_substitutions      in boolean                             default false )
is
    l_query_columns         apex_exec.t_columns;
    l_search_columns        apex_exec.t_columns;
    l_order_bys             apex_exec.t_order_bys;
    l_filters               apex_exec.t_filters     := p_filters;
    l_row_count             pls_integer             := 0;
    --
    l_lov_definition        varchar2(32767)         := p_item.lov_definition;
    l_is_web_source         boolean                 := false;
    l_allowed_columns       apex_t_varchar2;

    -- we have to re-fetch the LOV definition because the original definition had
    -- been wrapped in a subquery with just a select of the display/return value columns
    procedure get_shared_lov_definition (
        p_item apex_plugin.t_item )
    is
        l_lov              apex_application_lovs%rowtype;
        l_table_owner      varchar2(255);
    begin

        select *
          into l_lov
          from apex_application_lovs
         where application_id = apex_application.g_flow_id
           and lov_id         = p_item.shared_lov_id;

        if l_lov.source_type_code = 'TABLE' then
            if l_lov.table_owner is not null then
                l_table_owner := dbms_assert.enquote_name(l_lov.table_owner) || '.';
            end if;
            l_lov_definition := 'select * from ' || l_table_owner|| dbms_assert.enquote_name(l_lov.table_name);
            if l_lov.where_clause is not null then
                l_lov_definition := l_lov_definition || ' where '|| l_lov.where_clause;
            end if;
        elsif l_lov.source_type_code = 'SQL' then
            l_lov_definition := l_lov.list_of_values_query;
        end if;
        if l_lov.location_code = 'WEB_SOURCE' then
            l_is_web_source := true;
            --
            -- Note: web source / REST lov gets passed in with an inner query with hard coded column names DISP/VAL
            -- therefore we cannot support any additional columns due to this issue i.e.
            -- we only support display/return value, and no icon support e.g. here is an example of the problem
            --
            /*
            select i.*
             from (select "ISBN","TITLE","TAGS","PRICE"
            from(select d."ISBN",d."TITLE",d."TAGS",d."PRICE" from(select disp, val from table(wwv_flow_lov_api.get_remote_lov_data(483922666580821926)) t
            )d
             )i
            )i where 1=1 */

        end if;

    end get_shared_lov_definition;

begin
    if apex_application.g_debug then
        -- can't debug everything in one go as there are parameter limits on the "enter" API
        apex_debug.enter ( 'open_query_context',
                              'p_first_row',                p_first_row,
                              'p_max_rows',                 p_max_rows,
                              'p_search_operator',          p_search_operator,
                              'p_search_case_sensitive',    apex_debug.tochar(p_search_case_sensitive),
                              'p_item.shared_lov_id',       p_item.shared_lov_id,
                              'p_item.name',                p_item.name,
                              'p_item.lov_columns.count',   p_item.lov_columns.count,
                              'p_item.lov_display_column',  p_item.lov_display_column,
                              'p_item.lov_return_column',   p_item.lov_return_column );
    end if;

    if p_item.shared_lov_id is not null  then
        get_shared_lov_definition ( p_item => p_item );
    end if;

    if p_item.lov_columns.count = 0 or not p_supports_add_columns or l_is_web_source then
        -- Standard LOV or multiple columns are not supported by plug-in
        apex_debug.message('Standard LOV or multiple columns are not supported by plug-in');

        if p_item.lov_display_column is not null and p_item.lov_display_column <> p_item.lov_return_column then
            apex_exec.add_column(
                p_columns     => l_query_columns,
                p_column_name => p_item.lov_display_column );
        end if;

        apex_exec.add_column (
            p_columns     => l_query_columns,
            p_column_name => p_item.lov_return_column );

        -- We need a search column, display can be null so coalesce to return (which is required)
        apex_exec.add_column (
            p_columns     => l_search_columns,
            p_column_name => coalesce( p_item.lov_display_column, p_item.lov_return_column ),
            p_data_type   => apex_exec.c_data_type_varchar2 );

    else
        l_allowed_columns := get_column_references( p_item => p_item );
        -- LOV contains multiple columns
        for i in 1 .. p_item.lov_columns.count loop
            if p_item.lov_columns( i ).column_name member of l_allowed_columns then
                apex_exec.add_column (
                    p_columns     => l_query_columns,
                    p_column_name => p_item.lov_columns( i ).column_name,
                    p_data_type   => p_item.lov_columns( i ).data_type,
                    p_format_mask => p_item.lov_columns( i ).format_mask );

                -- suggestions need to be ordered first so we can grab the first one when getting the first
                -- record of the result set to display
                if  p_max_rows = 1 and p_item.lov_columns( i ).column_name = c_suggestion_column then
                    -- if there is a suggestion column, this will always be the primary sort order
                    apex_exec.add_order_by (
                        p_order_bys   => l_order_bys,
                        p_column_name => p_item.lov_columns( i ).column_name,
                        p_direction   => apex_exec.c_order_desc,
                        p_order_nulls => apex_exec.c_order_nulls_last );

                end if;

                -- only search for columns marked as searchable
                if p_item.lov_columns( i ).is_searchable then
                    apex_exec.add_column (
                        p_columns     => l_search_columns,
                        p_column_name => p_item.lov_columns( i ).column_name,
                        p_data_type   => p_item.lov_columns( i ).data_type );
                end if;
            end if;
        end loop;
    end if;

    -- Ordering: If p_order_bys contains any order bys, these override the default sorting logic. Allows plug-ins to support custom sorting
    if p_order_bys.count > 0 then
        for i in 1 .. p_order_bys.count loop
            apex_exec.add_order_by (
                p_order_bys   => l_order_bys,
                p_column_name => p_order_bys( i ).column_name,
                p_direction   => p_order_bys( i ).direction,
                p_order_nulls => p_order_bys( i ).order_nulls );
        end loop;
    else
        if p_item.lov_default_sort_column is not null then
            apex_debug.message('Is Web Source: %s ', apex_debug.tochar(l_is_web_source));
            -- It is possible that the default sort column is not defined in the query columns, so we need to check
            if not apex_exec.column_exists ( l_query_columns, p_item.lov_default_sort_column ) and not l_is_web_source then
                apex_exec.add_column(
                    p_columns           => l_query_columns,
                    p_column_name       => p_item.lov_default_sort_column );
            end if;
            apex_exec.add_order_by (
                p_order_bys   => l_order_bys,
                p_column_name => case when l_is_web_source then 'DISP' else p_item.lov_default_sort_column end,
                p_direction   => case
                                    when p_item.lov_default_sort_direction in ('DESC','DESC_NULLS_FIRST') then apex_exec.c_order_desc
                                    else apex_exec.c_order_asc
                                 end,
                p_order_nulls => case
                                    when p_item.lov_default_sort_direction in ('ASC','DESC') then apex_exec.c_order_nulls_last
                                    else apex_exec.c_order_nulls_first
                                 end );
        end if;
    end if;

    -- Icon column
    if  p_supports_icons and
        p_item.lov_icon_column is not null and
        not apex_exec.column_exists ( l_query_columns, p_item.lov_icon_column ) and
        not l_is_web_source
    then
        apex_exec.add_column (
            p_columns       => l_query_columns,
            p_column_name   => p_item.lov_icon_column );

    end if;

    -- Search
    if p_search_text is not null and not l_is_web_source then
        if p_item.lov_oracle_text_column is null then
            apex_exec.add_filter (
                p_filters           => l_filters,
                p_search_columns    => l_search_columns,
                p_search_operator   => p_search_operator,
                p_is_case_sensitive => p_search_case_sensitive,
                p_value             => p_search_text );
        else
            apex_exec.add_filter (
                p_filters             => l_filters,
                p_text_column_name    => p_item.lov_oracle_text_column,
                p_text_query_function => apex_application.g_oracle_text_function,
                p_value               => p_search_text );
        end if;
    end if;

    apex_debug.message('LOV Definition: %s', l_lov_definition);

    p_context := apex_exec.open_query_context (
        p_location            => apex_exec.c_location_local_db,
        p_sql_query           => l_lov_definition,
        p_columns             => l_query_columns,
        --
        p_first_row           => 1,
        p_max_rows            => p_max_rows,
        --
        p_filters             => l_filters,
        p_order_bys           => l_order_bys );

end open_query_context;
--==============================================================================
-- Open the query context for lov items
--==============================================================================
procedure open_query_context_lov_items (
    p_context            in out nocopy apex_exec.t_context,
    p_item               in apex_plugin.t_item,
    p_search_text        in varchar2            default null,
    p_filters            in apex_exec.t_filters default apex_exec.c_empty_filters,
    p_max_values_in_list in pls_integer         default null )
is
    c_has_additional_columns constant boolean      := p_item.lov_columns.count > 0;
    c_has_icon_column        constant boolean      := p_item.lov_icon_column is not null;
    c_match_type             constant varchar2(30) := nvl(p_item.attribute_01, c_contains);
    c_case_sensitive         constant boolean      := nvl(p_item.attribute_02, 'N') = 'Y';
    c_fetch_on_search        constant boolean      := nvl(p_item.attribute_04, 'N') = 'Y';
    c_max_values_in_list     constant number       :=
        case -- Only use max values when lazy loading.
            when c_fetch_on_search then
                coalesce (
                    p_max_values_in_list,            -- ajax: max_values_in_list (only used by AJAX calls and driven by JS client code)
                    p_item.attribute_07,             -- item: max_values_in_list (cannot be configured to more then 999)
                    c_lov_items_max_values_in_list ) -- default, when max_values_in_list not specified for item (is nullable)
        end;
    --
begin
    open_query_context (
        p_context               => p_context,
        p_max_rows              => coalesce(p_max_values_in_list, c_max_values_in_list),
        p_item                  => p_item,
        p_supports_icons        => c_has_icon_column,
        p_supports_add_columns  => c_has_additional_columns,
        p_filters               => p_filters,
        p_search_text           => p_search_text,
        p_search_operator       => case when c_match_type = c_contains
                                        then apex_exec.c_search_contains_instr
                                        else apex_exec.c_search_starts_with end,
        p_search_case_sensitive => c_case_sensitive );
end open_query_context_lov_items;

--==============================================================================
-- A value must always be shown, so it's either the value set in session state
-- or the first record from the result set
--==============================================================================
procedure populate_initial_value (
    p_item          in             apex_plugin.t_item,
    p_value         in             varchar2,
    p_json          in out nocopy  varchar2,
    p_display_value in out nocopy  varchar2 )
is
    l_context                apex_exec.t_context;
    l_filters                apex_exec.t_filters;
    l_value                  varchar2(32767);
    c_display_extra_values   constant boolean         := p_item.lov_display_extra;

begin

    if p_value is not null then
        apex_exec.add_filter (
            p_filters     => l_filters,
            p_filter_type => apex_exec.c_filter_eq,
            p_column_name => p_item.lov_return_column,
            p_value       => p_value );
    end if;

    open_query_context_lov_items (
        p_context            => l_context,
        p_item               => p_item,
        p_filters            => l_filters,
        p_max_values_in_list => 1 );

    -- if we do not find an initial value then we need to get the first value
    if not c_display_extra_values and apex_exec.get_total_row_count(l_context) = 0 then

        apex_exec.close(l_context);
        l_filters := apex_exec.t_filters();

        open_query_context_lov_items (
            p_context            => l_context,
            p_item               => p_item,
            p_filters            => l_filters,
            p_max_values_in_list => 1 );

    end if;

    -- we will set session state in here
    emit_initial_value (
        p_context       => l_context,
        p_item          => p_item,
        p_value         => p_value,
        p_json          => p_json,
        p_display_value => p_display_value );

    apex_exec.close(l_context);

exception when others then
    if l_context is not null then
        apex_exec.close(l_context);
    end if;
    raise;
end populate_initial_value;
--==============================================================================
-- Render the root button menu element to avoid replacing it on web component
-- initialization
--==============================================================================
procedure print_data_switcher_element (
    p_item          in  apex_plugin.t_item,
    p_display_value in varchar2 )
is
begin

    sys.htp.p ('
      <span class="rw-DataSwitcher" role="button" tabindex="0" aria-haspopup="true" aria-controls="POPUP_'||p_item.name||'">
        <span class="rw-DataSwitcher-label">'||apex_escape.html(p_display_value)||'</span>
        <span class="rw-DataSwitcher-icon oj-ux-ico-chevron-down" aria-hidden="true"></span>
      </span>
    ');

end print_data_switcher_element;

--==============================================================================
-- Check the plugin settings are valid
--==============================================================================
procedure check_configuration (
    p_plugin in             apex_plugin.t_plugin,
    p_item   in             apex_plugin.t_item )
is
    l_tpl_column_references apex_t_varchar2;
    l_exists                boolean             := false;
begin
    if p_item.lov_display_column is null then
        raise_error (
            p_message          => 'The display column is NULL, a column must be specified',
            p_page_item_name   => p_item.name );
    end if;

    -- check that template column references exist
    l_tpl_column_references := get_column_references(
                                p_item               => p_item,
                                p_template_cols_only => true );

    for i in 1.. l_tpl_column_references.count loop
        l_exists := false;
        for j in 1 .. p_item.lov_columns.count loop
            if l_tpl_column_references( i ) = p_item.lov_columns( j ).column_name then
                l_exists := true;
                exit;
            end if;
        end loop;
        if not l_exists then
            raise_error (
                p_message          => 'The column "'||l_tpl_column_references(i)||'" is defined in the plugin settings but does not exist in the Shared LOV columns',
                p_page_item_name   => p_item.name );
        end if;
    end loop;

end check_configuration;

--==============================================================================
-- Render the Redwood Data Switcher
--==============================================================================
procedure render (
    p_plugin in             apex_plugin.t_plugin,
    p_item   in             apex_plugin.t_item,
    p_param  in             apex_plugin.t_item_render_param,
    p_result in out nocopy  apex_plugin.t_item_render_result )
is

    l_value                 varchar2(32767)       := p_param.value;
    l_display_value         varchar2(32767);
    l_name                  apex_plugin.t_input_name;
    l_context               apex_exec.t_context;
    l_initial_value_json    varchar2(32767);
    l_display_value_list    apex_application_global.vc_arr2;
    l_json_array            sys.json_array_t;

    --
    c_match_type             constant varchar2(30)    := nvl(p_item.attribute_01, c_contains);
    c_case_sensitive         constant boolean         := nvl(p_item.attribute_02, 'N') = 'Y';
    c_fetch_on_search        constant boolean         := nvl(p_item.attribute_04, 'N') = 'Y';
    c_debounce_delay         constant number          := p_item.attribute_05;
    c_show_search_after      constant number          := case when p_item.attribute_06 = 'default' then c_show_search_after_default else nvl(p_item.attribute_06, c_show_search_after_default) end;
    c_max_values_in_list     constant number          := nvl(p_item.attribute_07, c_lov_items_max_values_in_list);
    c_min_search_characters  constant number          := nvl(p_item.attribute_03, 0);
    c_cache                  constant boolean         := nvl(p_item.attribute_08, 'N') = 'Y';
    -- Template
    c_use_list_item_template constant boolean         := nvl(p_item.attribute_16, 'N') = 'Y';
    c_use_avatar_template    constant boolean         := nvl(p_item.attribute_09, 'none') like 'avatar-%';
    c_use_icon_template      constant boolean         := nvl(p_item.attribute_09, 'none') = 'icon';
    c_image_src_column       constant varchar2(32767) := trim(p_item.attribute_17);
    c_icon_column            constant varchar2(32767) := trim(p_item.attribute_10);
    c_initials_column        constant varchar2(32767) := trim(p_item.attribute_11);
    c_overline_column        constant varchar2(32767) := trim(p_item.attribute_18);
    c_primary_txt_column     constant varchar2(32767) := trim(p_item.attribute_19);
    c_secondary_txt_column   constant varchar2(32767) := trim(p_item.attribute_20);
    c_tertiary_txt_column    constant varchar2(32767) := trim(p_item.attribute_21);
    c_meta_column            constant varchar2(32767) := trim(p_item.attribute_22);
    --
    c_when_no_data_found     constant varchar2(32767) := nvl(apex_plugin_util.replace_substitutions(p_item.attribute_12), 'No Data Found');
    c_when_no_matches_found  constant varchar2(32767) := nvl(apex_plugin_util.replace_substitutions(p_item.attribute_13), 'No Matches Found');
    c_suggestion             constant varchar2(32767) := nvl(apex_plugin_util.replace_substitutions(p_item.attribute_23), 'Suggestion');
    c_submit_on_change       constant boolean         := nvl(p_item.attribute_14, 'N') = 'Y';
    c_dialog_width           constant varchar2(255)   := nvl(p_item.attribute_15, '400');
    c_display_extra_values   constant boolean         := p_item.lov_display_extra;
    c_placeholder            constant varchar2(4000)  := p_item.placeholder;
    c_required               constant boolean         := p_item.is_required;
    c_has_icons              constant boolean         := p_item.lov_icon_column is not null;

    -- Item attributes
    c_items_to_submit       varchar2(32767)           := apex_plugin_util.item_names_to_jquery (
                                                             p_item_names => p_item.ajax_items_to_submit,
                                                             p_item       => p_item );
    c_depends_on            varchar2(32767)           := apex_plugin_util.item_names_to_jquery (
                                                             p_item_names => p_item.lov_cascade_parent_items,
                                                             p_item       => p_item );

begin
    if apex_application.g_debug then
        apex_debug.enter( 'render_redwood_data_switcher'    ,
                              'p_item.name' , p_item.name   ,
                              'p_item.id'   , p_item.id     );
    end if;

    -- Check for invalid configurations
    check_configuration ( p_plugin => p_plugin,
                          p_item   => p_item );

    -- this will set session state for the item value, as it might be the default/first row returned
    populate_initial_value (
        p_item          => p_item,
        p_value         => l_value,
        p_json          => l_initial_value_json,
        p_display_value => l_display_value );

    -- We will just display the markup for the button, no need to add the web component to the page
    if p_param.is_readonly or p_param.is_printer_friendly then

        sys.htp.p('<span class="rw-DataSwitcher">
        <span class="rw-DataSwitcher-label">');
        apex_plugin_util.print_read_only (
            p_item              => p_item,
            p_param             => p_param,
            p_display_value     => l_display_value,
            p_css_classes       => 'rw-DataSwitcher-readonly' ); -- APEX bug, class is not outputted
        sys.htp.p('</span>
        <span class="rw-DataSwitcher-icon oj-ux-ico-chevron-down" aria-hidden="true"></span>
      </span>');
    else

        -- If a page item saves state, we have to call the get_input_name_for_item to indicate to the
        -- browser that the input field should be submitted.
        l_name := apex_plugin.get_input_name_for_item;

        -- webcomponents have an API to run our Javascript Initialization Code
        if p_item.init_javascript_code is not null then
            apex_javascript.add_inline_code (
                p_code => 'apex.WebComponent._registerInitFunc( {' || chr(10) ||
                          '   elementId: ' || apex_javascript.add_value( l_name ) || chr(10) ||
                          '   func: ' || p_item.init_javascript_code || chr(10) ||
                          '} );' );
        end if;

        -- render the data switcher web component
        sys.htp.p (
            '<rw-data-switcher ' ||
                apex_plugin_util.get_element_attributes (
                    p_item            => p_item,
                    p_name            => l_name,
                    p_add_multi_value => false ) ||

            -- to save an initial AJAX call to get the display value(s) we provide it here
            case when l_initial_value_json is not null then
                ' initial-value="' || apex_escape.html_attribute(l_initial_value_json) || '"' end ||

            ' show-search-after-rows="' || apex_escape.html_attribute(c_show_search_after) || '"' ||
            ' max-results="' || apex_escape.html_attribute(c_max_values_in_list) || '"' ||

            case when c_submit_on_change then
                ' submit-on-change="true"' end ||

            case when c_required then
                ' required="true"' end ||

            case when c_min_search_characters is not null then
                ' min-characters-search="' || apex_escape.html_attribute(c_min_search_characters) || '"' end ||

            ' match-type="' || apex_escape.html_attribute( c_match_type ) || '"' ||

            case when l_initial_value_json is not null then
                ' debounce-delay="' || apex_escape.html_attribute(c_debounce_delay)  || '"' end ||

            case when c_case_sensitive then
                ' case-sensitive="true"' end ||

            case when c_fetch_on_search then
                ' fetch-on-search="true"' end ||

            case when c_has_icons then
                ' has-icons="true"' end ||

            case when c_display_extra_values then
                ' display-extra-values="true"' end ||

            case when c_dialog_width is not null then
                '  dialog-width="'||c_dialog_width||'"' end ||

            case when p_item.element_max_length is not null then
                ' maxlength="'||p_item.element_max_length||'"' end ||

            case when c_fetch_on_search and c_cache then
                ' cache="true"' end ||

            case when c_when_no_data_found is not null then
                ' no-data-found-message="' || apex_escape.html_attribute(c_when_no_data_found) || '"' end ||

            case when c_suggestion is not null then
                ' suggestion-message="' || apex_escape.html_attribute(c_suggestion) || '"' end ||

            case when c_when_no_matches_found is not null then
                ' no-results-hint="' || apex_escape.html_attribute(c_when_no_matches_found) || '"' end ||

            ' ajax-identifier="' || apex_plugin.get_ajax_identifier || '"' ||

            case when c_items_to_submit is not null then
                ' ajax-items="' || apex_escape.html_attribute(c_items_to_submit) || '"' end ||

            case when c_depends_on is not null then
                ' parent-items="' || apex_escape.html_attribute(c_depends_on) || '"' end ||

            case when p_item.ajax_optimize_refresh then
                ' parents-required="true"' end ||

            case when c_placeholder is not null then
                ' placeholder="' || apex_escape.html_attribute(c_placeholder) || '"' end ||

            case when c_use_list_item_template then
                ' use-list-item-template="true"' end ||

            case when c_use_icon_template then
                ' use-icon-template="true"' end ||

            case when c_use_avatar_template then
                ' use-avatar-template="true"' end ||

            case when c_image_src_column is not null then
                ' avatar-image-source-column="' || apex_escape.html_attribute ( c_image_src_column ) || '"' end ||

            case when c_icon_column is not null then
                ' avatar-icon-column="' || apex_escape.html_attribute ( c_icon_column ) || '"' end ||

            case when c_initials_column is not null then
                ' avatar-initials-column="' || apex_escape.html_attribute ( c_initials_column ) || '"' end ||

            case when c_overline_column is not null then
                ' overline-column="' || apex_escape.html_attribute ( c_overline_column ) || '"' end ||

            case when c_primary_txt_column is not null then
                ' primary-text-column="' || apex_escape.html_attribute ( c_primary_txt_column ) || '"' end ||

            case when c_secondary_txt_column is not null then
                ' secondary-text-column="' || apex_escape.html_attribute ( c_secondary_txt_column ) || '"' end ||

            case when c_tertiary_txt_column is not null then
                ' tertiary-text-column="' || apex_escape.html_attribute ( c_tertiary_txt_column ) || '"' end ||

            case when c_meta_column is not null then
                ' meta-column="' || apex_escape.html_attribute ( c_meta_column ) || '"' end ||

            ' value="' || apex_escape.html_attribute( v(p_item.name) ) || '"' ||

            '>' );

        if not c_fetch_on_search then

            -- we print out all the lov items on page render
            open_query_context_lov_items (
                p_context            => l_context,
                p_item               => p_item,
                p_max_values_in_list => c_max_values_in_list );

            emit_data_lov_items (
                p_context       => l_context,
                p_item          => p_item,
                p_data_type     => c_html);

            apex_exec.close(l_context);

        end if;

        -- Render the item icon
        apex_plugin_util.print_item_icon (p_item => p_item);

        -- this is the actual rendered element/button/picker
        print_data_switcher_element (
            p_item          => p_item,
            p_display_value => l_display_value );

        sys.htp.p ('</rw-data-switcher>' );

        p_result.is_navigable := true;

    end if;

exception when others then
    if l_context is not null then
        apex_exec.close(l_context);
    end if;
    raise;
end render;

--==============================================================================
-- AJAX Redwood Data Switcher
--==============================================================================
procedure ajax (
    p_plugin in             apex_plugin.t_plugin,
    p_item   in             apex_plugin.t_item,
    p_param  in             apex_plugin.t_item_ajax_param,
    p_result in out nocopy  apex_plugin.t_item_ajax_result )
is
    l_display_value        varchar2(32767);
    l_context              apex_exec.t_context;
    l_filters              apex_exec.t_filters;

    -- widget AJAX actions
    c_get_value              constant varchar2(255)   := 'get-value';
    c_get_first_value        constant varchar2(255)   := 'get-first-value';
    c_fetch_choices          constant varchar2(255)   := 'fetch-choices';

    -- Dynamic attribute mapping
    c_search_text            constant varchar2(32767) :=     apex_application.g_x01;
    l_max_values_in_list            number            := nvl(p_item.attribute_07, c_lov_items_max_values_in_list);
    c_return_value           constant varchar2(32767) :=     apex_application.g_x01;
    c_widget_action          constant varchar2(32767) :=     apex_application.g_widget_action;
    c_display_extra_values   constant boolean         :=     p_item.lov_display_extra;
    c_when_no_data_found     constant varchar2(32767) := nvl(apex_plugin_util.replace_substitutions(p_item.attribute_12), 'No Data Found');
    c_min_search_characters  constant number          := nvl(p_item.attribute_03, 0);

    -- helper to convert JSON array into APEX array (apex_t_varchar2)
    function get_filter_value return apex_t_varchar2 is
        l_vc2_array  apex_t_varchar2;
    begin
            apex_string.push (
                p_table => l_vc2_array,
                p_value => c_return_value );
        return l_vc2_array;
    end;
    --
begin
    if apex_application.g_debug then
        apex_debug.enter (
            'ajax_redwood_data_switcher' ,
            'p_item.id'            , p_item.id,
            'c_search_text'        , c_search_text,
            'l_max_values_in_list' , l_max_values_in_list,
            'c_widget_action'      , c_widget_action );
    end if;

    -- Write header for the JSON stream.
    apex_plugin_util.print_json_http_header;

    if c_widget_action = c_get_first_value or (c_widget_action = c_get_value and c_search_text is null) then
        l_max_values_in_list := 1;
    end if;

    if c_widget_action = c_get_value then

        if c_search_text is not null then
            apex_exec.add_filter (
                p_filters     => l_filters,
                p_filter_type => apex_exec.c_filter_eq,
                p_column_name => p_item.lov_return_column,
                p_values      => get_filter_value );
        end if;

        open_query_context (
            p_context => l_context,
            p_item    => p_item,
            p_filters => l_filters );
    else
        if nvl(length(c_search_text),0) >= c_min_search_characters then
            open_query_context_lov_items (
                p_context            => l_context,
                p_item               => p_item,
                p_search_text        => c_search_text,
                p_max_values_in_list => l_max_values_in_list );
        end if;
    end if;

    -- if we do not find an initial value then we need to raise an error
    if c_widget_action = c_get_value and not c_display_extra_values and apex_exec.get_total_row_count(l_context) = 0 then

        handle_ajax_error (
            p_component_name => p_item.name,
            p_message        => c_when_no_data_found );

    else

        if c_widget_action != c_fetch_choices or
         ( c_widget_action  = c_fetch_choices and nvl(length(c_search_text),0) >= c_min_search_characters )
        then
            emit_data_lov_items (
                p_context       => l_context,
                p_item          => p_item,
                p_data_type     => c_json,
                -- we pass the value through in case we need to emit the "display extra value"
                p_value         => case when c_widget_action = c_get_value then c_return_value else null end );
        else
            emit_empty_response;
        end if;

        -- this is to ensure that cascading LOV's always have a correct value in session state, based on their parent
        if c_widget_action = c_fetch_choices and p_item.lov_cascade_parent_items is not null then
            apex_util.set_session_state(p_item.name, g_first_value);
        end if;

    end if;

    apex_exec.close(l_context);

exception when others then
    if l_context is not null then
        apex_exec.close(l_context);
    end if;
    apex_debug.error( dbms_utility.format_error_backtrace );
    handle_ajax_error (
        p_component_name => p_item.name,
        p_message        => sqlerrm );
end ajax;

end "REDWOOD_DATA_SWITCHER_PLUGIN";
/